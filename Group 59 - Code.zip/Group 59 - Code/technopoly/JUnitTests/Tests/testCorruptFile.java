package Tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Classes.CorruptFile;
import Classes.CurrentStage;
import Classes.File;
import Classes.FileType;
import Classes.Player;
import Classes.RecyclingBin;

public class testCorruptFile {
	private CorruptFile corruptFile;
	private Player player1;
	private File file1;
	private RecyclingBin recyclingBin;

	
	public void setUp(){
		Classes.File[] corruptFileArray = {};
		
		corruptFile = new CorruptFile("Corrupt File", (byte)2);
		
		file1 = new Classes.File("Euston Road.docx", (byte)8, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		
		recyclingBin = new RecyclingBin("Recycle Bin", (byte)20, corruptFileArray);
		
		File[] player1Files = {file1};

		player1 = new Player("Scott", (byte)0, 800, player1Files, (byte)0, 0);
	}
	
	//Testing a file being taken away from the user (only one file to "randomly" select)
	@Test
	public void testLoseFileWhenPlayerHasFiles() {
		setUp();
		
		File[] emptyFiles = {};
		
		corruptFile.loseFile(player1, recyclingBin);
		
		assertEquals(emptyFiles, player1.getFilesOwned());
	}
	
	//No files to randomly select
	@Test
	public void testLoseFileWhenPlayerHasNoFiles() {
		setUp();
		
		File[] emptyFiles = {};
		
		player1.setFilesOwned(emptyFiles);
		corruptFile.loseFile(player1, recyclingBin);
		
		assertEquals(emptyFiles, recyclingBin.getCorruptFileArray());
	}
}
