package Tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Classes.DownloadVirus;
import Classes.Player;
import Classes.SafeMode;

public class testDownloadVirus {

	@Test
	public void testDownloadVirus() {
		DownloadVirus newVirus = new DownloadVirus("Trojan", (byte)0, (byte)0);
	}
	
	
	//NOT WORKING
	@Test
	public void testDownloadingVirus() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		
		DownloadVirus newVirus = new DownloadVirus("Trojan", (byte)0, (byte)0);
		Player[] playersInSafeMode = new Player[4];
		byte[] timeSpentInSafeMode = new byte[4];
		SafeMode safeMode = new SafeMode("Safe Mode", (byte)10, playersInSafeMode, timeSpentInSafeMode);
		
		newVirus.downloadingVirus(newPlayer, safeMode);
		int expectedResult = 10;
		
		assertTrue(newPlayer.getPositionAt() == expectedResult);

	}


	@Test
	public void testGetSeverityOfVirus() {
		DownloadVirus newVirus = new DownloadVirus("Trojan", (byte)0, (byte)0);
		byte expectedResult = 1;
		
		assertTrue(newVirus.getSeverityOfVirus() == expectedResult);
	}

	@Test
	public void testSetSeverityOfVirus() {
		DownloadVirus newVirus = new DownloadVirus("Trojan", (byte)0, (byte)1);
		byte expectedResult = 1;
		newVirus.setSeverityOfVirus((byte)0);
		
		assertTrue(newVirus.getSeverityOfVirus() == expectedResult);
	}

}
