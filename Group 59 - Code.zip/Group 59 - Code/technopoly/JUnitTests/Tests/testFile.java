package Tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Classes.CurrentStage;
import Classes.File;
import Classes.FileType;
import Classes.Player;
import Classes.SafeMode;

public class testFile {
	private Player player1;
	private Player player2;
	private Player player3;
	private Player player4;
	private File file1;
	private File file2;
	private File file3;
	private File file4;
	private File file5;
	private File file6;
	private File file7;
	
	public void setUpFiles() {
		file1 = new Classes.File("Euston Road.docx", (byte)8, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file2 = new Classes.File("Pentonville Road.docx", (byte)9, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file3 = new Classes.File("The Angel Islington.docx", (byte)6, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file4 = new Classes.File("Whitehall.svg", (byte)13, 200, 200, 200, CurrentStage.Downloaded, FileType.svg, 200, 200, 200);
		file5 = new Classes.File("Northumberland Avenue.svg", (byte)14, 200, 200, 200, CurrentStage.Downloaded, FileType.svg, 200, 200, 200);
		file6 = new Classes.File("Marlborough Street.pptx", (byte)18, 200, 200, 200, CurrentStage.Downloaded, FileType.pptx, 200, 200, 200);
		file7 = new Classes.File("Vine Street.pptx", (byte)19, 200, 200, 200, CurrentStage.NotOwned, FileType.pptx, 200, 200, 200);
	}
	
	public void setUpPlayers(){
		File[] player1Files = {file1, file2, file3};
		File[] player2Files = {file4, file5};
		File[] player3Files = {file6};
		File[] player4Files = {};
		
		player1 = new Player("Dean", (byte)0, 800, player1Files, (byte)0, 0);
		player2 = new Player("JB", (byte)1, 40, player2Files, (byte)0, 0);
		player3 = new Player("Scott", (byte)2, 500, player3Files, (byte)0, 0);
		player4 = new Player("Conor", (byte)3, 340, player4Files, (byte)0, 0);
	}

	@Test
	public void testDownloadingFile() {
		setUpFiles();
		setUpPlayers();
		
		file6.downloadingFile(player4);
		
		File[] player4Files = {file6};
		
		assertEquals(player4Files, player4.getFilesOwned());
	}

	@Test
	public void testInstallingFile() {
		setUpFiles();
		setUpPlayers();
		
		file1.setCurrentStage(CurrentStage.Setup3);
		
		file1.installingFile(player1);
		
		assertEquals(CurrentStage.Installed, file1.getCurrentStage());
	}

	@Test
	public void testDoesntOwnAllFileTypesForSetup() {
		setUpFiles();
		setUpPlayers();

		file4.setupProcess(player2);
		
		assertEquals(CurrentStage.Downloaded, file4.getCurrentStage());
	}
	
	@Test
	public void testsetupProcess() {
		setUpFiles();
		setUpPlayers();

		file1.setupProcess(player1);
		
		assertEquals(CurrentStage.Setup1, file1.getCurrentStage());
	}

	@Test
	public void testCheckWhoOwnsFile() {
		setUpFiles();
		setUpPlayers();
		
		Player[] playerArr = {player1, player2, player3, player4};
		
		assertEquals(player1, file1.checkWhoOwnsFile(playerArr));
	}

	@Test
	public void testChargeUser() {
		setUpFiles();
		setUpPlayers();
		
		file1.chargeUser(player3, player1);
		
		assertEquals(1000, player1.getStorageSpace());
		assertEquals(300, player3.getStorageSpace());
	}
}
