package Tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Classes.FileExplorer;
import Classes.CurrentStage;
import Classes.File;
import Classes.FileType;
import Classes.Player;

public class testFileExplorer {
	private FileExplorer fileExplorer;
	private Player player1;
	private Player player2;
	private Player player3;
	private Player player4;
	private File file1;
	private File file2;
	private File file3;
	private File file4;
	private File file5;
	
	
	public void setUp(){
		
		file1 = new Classes.File("Conor.docx", (byte)8, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file2 = new Classes.File("JB.docx", (byte)9, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file3 = new Classes.File("Scott.docx", (byte)10, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file4 = new Classes.File("Dean.docx", (byte)1, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		file5 = new Classes.File("Reo.docx", (byte)35, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);
		
		fileExplorer = new FileExplorer("File Explorer 1", (byte)5, 50);
		
		File[] player1Files = {file1,file2,file3,file4};
		File[] player2Files = {};

		player1 = new Player("Scott", (byte)0, 800, player1Files, (byte)1, 5);
		player2 = new Player("Brian", (byte)0, 800, player2Files, (byte)0, 15);
		player3 = new Player("Judith", (byte)0, 800, player1Files, (byte)0, 25);
		player4 = new Player("Dirk", (byte)0, 30, player1Files, (byte)0, 35);
	}
	
	@Test
	public void testSelectOptionWhenNoBits() {
		setUp();
		byte testCase = file1.getPosition();
		fileExplorer.movePlayer(player4,file1);
		assertEquals(35,player4.getPositionAt());
	}
	
	@Test
	public void testFare() {
		setUp();
		
		fileExplorer.movePlayer(player1,file1);
		
		assertEquals(750, player1.getStorageSpace());
	}
	
	@Test
	public void testTravel() {
		setUp();
		
		byte testCase = file1.getPosition();
		
		fileExplorer.movePlayer(player1,file1);
		
		assertEquals(testCase, player1.getPositionAt());
	}
	
	@Test
	public void testNoUtilCard() {
		setUp();
		
		fileExplorer.utilCardCheck(player3);
		
		assertEquals(750, player3.getStorageSpace());
	}
	
	@Test
	public void testUtilCard() {
		setUp();
		
		fileExplorer.utilCardCheck(player1);
		
		assertEquals(950, player1.getStorageSpace());
	}
	
	@Test
	public void testNoFiles() {
		setUp();
		
		int testCase = player2.getPositionAt();
		
		fileExplorer.selectOption(player2);
		
		assertEquals(testCase, player2.getPositionAt());
	}
}
