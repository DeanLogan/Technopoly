package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testGame {

	@Test
	void testGame() {
		fail("Not yet implemented");
	}

	@Test
	void testInitialisePlayers() {
		fail("Not yet implemented");
	}

	@Test
	void testInitialiseDice() {
		fail("Not yet implemented");
	}

	@Test
	void testInitialiseLocations() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayResults() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayRuleSet() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayBoardLayout() {
		fail("Not yet implemented");
	}

	@Test
	void testFinishGame() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayOptionsForPlayer() {
		fail("Not yet implemented");
	}

	@Test
	void testVoteToFinishGame() {
		fail("Not yet implemented");
	}

	@Test
	void testMovePlayer() {
		fail("Not yet implemented");
	}

	@Test
	void testDeterminePlayerOrder() {
		fail("Not yet implemented");
	}

	@Test
	void testTitleScreen() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayFilesOwned() {
		fail("Not yet implemented");
	}

	@Test
	void testOrganiseFiles() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPlayerArray() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPlayerArray() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDiceOne() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDiceOne() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDiceTwo() {
		fail("Not yet implemented");
	}

	@Test
	void testSetDiceTwo() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLocationArray() {
		fail("Not yet implemented");
	}

	@Test
	void testSetLocationArray() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCurrentPlayer() {
		fail("Not yet implemented");
	}

	@Test
	void testSetCurrentPlayer() {
		fail("Not yet implemented");
	}

}
