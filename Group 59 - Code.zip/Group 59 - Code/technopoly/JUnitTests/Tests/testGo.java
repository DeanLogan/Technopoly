package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Classes.Go;
import Classes.Player;

class testGo {

	@Test
	void testGo() {
		Go newGo = new Go("Go", (byte)0, 200);

	}

	@Test
	void testGivePlayerCollectAmount() {
		Go newGo = new Go("Go", (byte)0, 200);
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		int expectedResult = newPlayer.getStorageSpace() + 200;
		
		newGo.givePlayerCollectAmount(newPlayer);
		
		assertTrue(newPlayer.getStorageSpace() == expectedResult);
		
	}

	@Test
	void testGetCollectAmount() {
		Go newGo = new Go("Go", (byte)0, 200);
		int retrievedAmount = newGo.getCollectAmount();
		int expectedResult = 200;
		
		assertTrue(retrievedAmount == expectedResult);
	}

	@Test
	void testSetCollectAmount() {
		Go newGo = new Go("Go", (byte)0, 0);
		newGo.setCollectAmount(200);
		int retrievedAmount = newGo.getCollectAmount();
		int expectedResult = 200;
		
		assertTrue(retrievedAmount == expectedResult);
	}

}
