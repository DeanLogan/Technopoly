package Tests;

import static org.junit.Assert.*;

import org.junit.Test;

import Classes.Location;

public class testLocation {
	private Location location;
	
	public void setUp() {
		location = new Location("location", (byte)20);
	}
	
	@Test
	public void testGetName() {
		setUp();
		
		assertEquals("location", location.getName());
	}

	@Test
	public void testSetName() {
		setUp();
		
		location.setName("corrupt file");
		
		assertEquals("corrupt file", location.getName());
	}

	@Test
	public void testGetPosition() {
		setUp();
		
		assertEquals(20, location.getPosition());
	}

	@Test
	public void testSetPosition() {
		setUp();
		
		location.setPosition((byte) 8);
		
		assertEquals(8, location.getPosition());
	}

}
