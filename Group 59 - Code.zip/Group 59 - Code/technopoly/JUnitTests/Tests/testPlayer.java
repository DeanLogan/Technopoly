package Tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

import Classes.CurrentStage;
import Classes.File;
import Classes.FileType;
import Classes.Location;
import Classes.Player;

class testPlayer {

	@Test
	void testPlayer() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		
	}

	@Test
	void testGetName() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		String expectedResult = "Mrs. Test";
		
		assertEquals(expectedResult, newPlayer.getName());
	}

	@Test
	void testSetName() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player(null, (byte)1, 200, filesOwned, (byte)2, 2);
		String expectedResult = "Mrs. Test";
		newPlayer.setName("Mrs. Test");
		
		assertEquals(expectedResult, newPlayer.getName());
	}

	@Test
	void testGetId() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		byte expectedResult = 1;
		
		assertTrue(newPlayer.getId() == expectedResult);
	}

	@Test
	void testSetId() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)0, 200, filesOwned, (byte)2, 2);
		byte expectedResult = 1;
		newPlayer.setId((byte)1);
		
		assertTrue(newPlayer.getId() == expectedResult);
	}

	@Test
	void testGetStorageSpace() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		int expectedResult = 200;
		
		assertTrue(newPlayer.getStorageSpace() == expectedResult);
	}

	@Test
	void testSetStorageSpace() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 0, filesOwned, (byte)2, 2);
		int expectedResult = 200;
		newPlayer.setStorageSpace(200);
		
		assertTrue(newPlayer.getStorageSpace() == expectedResult);
	}

	@Test
	void testGetFilesOwned() {
		Classes.File mayfairOne = new Classes.File("Mayfair.one", (byte)39, 200, 200, 200, CurrentStage.NotOwned, FileType.one, 200, 200, 200);
		Classes.File[] filesOwned = {mayfairOne};
		
		Player newPlayer = new Player("Mrs. Test", (byte)1, 0, filesOwned, (byte)2, 2);
		Classes.File[] expectedResult = {mayfairOne};
		
		assertTrue(Arrays.equals(newPlayer.getFilesOwned(),expectedResult));
		
	}

	@Test
	void testSetFilesOwned() {
		Classes.File mayfairOne = new Classes.File("Mayfair.one", (byte)39, 200, 200, 200, CurrentStage.NotOwned, FileType.one, 200, 200, 200);
		Classes.File[] filesOwnedToSet = {mayfairOne};
		Classes.File[] filesOwned = {};
		
		Player newPlayer = new Player("Mrs. Test", (byte)1, 0, filesOwned, (byte)2, 2);
		Classes.File[] expectedResult = {mayfairOne};
		newPlayer.setFilesOwned(filesOwnedToSet);
		
		assertTrue(Arrays.equals(newPlayer.getFilesOwned(),expectedResult));
	}

	@Test
	void testGetUtilPass() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		byte expectedResult = 2;
		
		assertTrue(newPlayer.getUtilPass() == expectedResult);
	}

	@Test
	void testSetUtilPass() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)0, 2);
		byte expectedResult = 2;
		newPlayer.setUtilPass((byte)2);
		
		assertTrue(newPlayer.getUtilPass() == expectedResult);
	}

	@Test
	void testGetPositionAt() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 2);
		int expectedResult = 2;
		
		assertTrue(newPlayer.getPositionAt() == expectedResult);
	}

	@Test
	void testSetPositionAt() {
		Classes.File[] filesOwned = {};
		Player newPlayer = new Player("Mrs. Test", (byte)1, 200, filesOwned, (byte)2, 0);
		int expectedResult = 2;
		newPlayer.setPositionAt(2);
		
		assertTrue(newPlayer.getPositionAt() == expectedResult);
	}

}
