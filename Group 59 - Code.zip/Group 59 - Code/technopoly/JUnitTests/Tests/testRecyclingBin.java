package Tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Classes.CorruptFile;
import Classes.CurrentStage;
import Classes.File;
import Classes.FileType;
import Classes.Player;
import Classes.RecyclingBin;

public class testRecyclingBin {
	private RecyclingBin recyclingBin1;
	private RecyclingBin recyclingBin2;
	private RecyclingBin recyclingBin3;
	private CorruptFile corruptFile;
	private Player player1;
	private File file1;
	private File file2;
	

	
	public void setUp(){
		
		file1 = new Classes.File("Euston Road.docx", (byte)8, 200, 200, 200, CurrentStage.Downloaded, FileType.docx, 200, 200, 200);;
		file2 = new Classes.File("Mayfair.one", (byte)39, 500, 400, 1000, CurrentStage.NotOwned, FileType.one, 300, 200, 500);
		Classes.File[] corruptFileArray1 = {file1};
		
		recyclingBin1 = new RecyclingBin("Recycle Bin1", (byte)20, corruptFileArray1);
		
		File[] player1Files = {};

		player1 = new Player("Scott", (byte)0, 800, player1Files, (byte)0, 0);
	}
	
	@Test
	public void testGivingCorruptFiles() {
		setUp();
		
		File[] testCase = {file1};
		
		System.out.println(testCase);
		
		recyclingBin1.giveFilesToPlayer(player1, file1);
		
		System.out.println(player1.getFilesOwned());
		
		assertEquals(testCase, player1.getFilesOwned());
	}
}
