package Tests;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

import Classes.File;
import Classes.Player;
import Classes.SafeMode;

public class testSafeMode {
	private SafeMode safeMode;
	private Player player1;
	
	public void setUpSafeMode() {
		Player[] playersInSafeMode = new Player[4];
		byte[] timeSpentInSafeMode = new byte[4];
		
		safeMode = new SafeMode("Safe Mode", (byte)10, playersInSafeMode, timeSpentInSafeMode);
	}
	
	public void setUpPlayer() {
		File[] filesOwned = {};
		
		player1 = new Player("Dean", (byte)0, 200, filesOwned, (byte)0, 0);
		
		Player[] playersInSafeMode = new Player[4];
		byte[] timeSpentInSafeMode = new byte[4];
		playersInSafeMode[0] = player1;
		timeSpentInSafeMode[0] = (byte)3;
		
		safeMode.setPlayersInSafeMode(playersInSafeMode);
		safeMode.setTimeSpentInSafeMode(timeSpentInSafeMode);
	}

	@Test
	public void testGoToSafeMode() {
		setUpSafeMode();
		
		player1 = new Player("Dean", (byte)0, 200, null, (byte)0, 0);
		safeMode.goToSafeMode(player1, 3);
		
		Player[] playersInSafeMode = {player1, null, null, null};
		
		assertEquals(playersInSafeMode, safeMode.getPlayersInSafeMode());
	}

	@Test
	public void testCanBuyForFreedom() {
		setUpSafeMode();
		setUpPlayer();
		
		assertTrue(safeMode.buyForFreedom(player1));
	}
	
	@Test
	public void testCantBuyForFreedom() {
		setUpSafeMode();
		setUpPlayer();
		
		player1.setStorageSpace(10);
		
		assertFalse(safeMode.buyForFreedom(player1));
	}

	@Test
	public void testRollForFreedom() { //this test might have to be run a couple times for it to work properly 
		setUpSafeMode();
		setUpPlayer();
		
		assertTrue(safeMode.buyForFreedom(player1));
	}

	@Test
	public void testGetFreedom() {
		setUpSafeMode();
		setUpPlayer();
		
		byte[] timeSpentInSafeMode = {0, 0, 0, 0};
		safeMode.setTimeSpentInSafeMode(timeSpentInSafeMode);
		Player[] playersInSafeMode = {null, null, null, null};
		
		safeMode.getFreedom(player1);
		
		assertEquals(playersInSafeMode, safeMode.getPlayersInSafeMode());
	}

	@Test
	public void testPlayerFoundInSafeMode() {
		setUpSafeMode();
		setUpPlayer();
		
		assertTrue(safeMode.searchPlayerInSafeMode(player1));
	}
	
	@Test
	public void testPlayerNotFoundInSafeMode() {
		setUpSafeMode();
		
		player1 = new Player("Dean", (byte)0, 200, null, (byte)0, 0);
		
		assertFalse(safeMode.searchPlayerInSafeMode(player1));
	}
	
	@Test
	public void testGetTimeSpentInSafeMode() {
		setUpSafeMode();
		
		byte[] testArray = new byte[4];
		
		assertTrue(Arrays.equals(testArray, safeMode.getTimeSpentInSafeMode()));
	}
}
