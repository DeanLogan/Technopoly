package Tests;

import static org.junit.Assert.*;

import org.junit.Test;

import Classes.File;
import Classes.Player;
import Classes.Utility;

public class testUtility {
	private Utility utility;
	private Player player;
	
	public void setUp() {
		File[] filesOwned = {};
		
		player = new Player("Dean", (byte)0, 200, filesOwned, (byte)0, 0);
		
		utility = new Utility("Utility", (byte)4);
	}	
	
	
	@Test
	public void testGivePlayerUtilCard() {
		setUp();
		
		utility.givePlayerUtilCard(player);
		
		assertEquals(1, player.getUtilPass());
	}

}
