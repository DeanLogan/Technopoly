package Classes;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

//This is our main class and where the game should be run from
public class Controller {

	public static void main(String[] args) throws FileNotFoundException {

		Game game = new Game();
		
		game.titleScreen(); // the starting of the game
	}
}
