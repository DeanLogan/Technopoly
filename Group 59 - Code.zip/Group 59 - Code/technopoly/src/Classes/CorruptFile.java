package Classes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;


public class CorruptFile extends Location{
	
	public CorruptFile(String name, byte position) {
		super(name, position); 
	}
	
	/* Sends the corruptFile to the recycling bin
	 * @param recyclingBin - Object of the RecyclingBin class where the corruptFile will be placed
	 * @param corruptFile - The file which will be sent to the recycling bin
	 * @return recyclingBin - The updated Object of the RecyclingBin class
	 * @author Scott McDonald
	 */
	public RecyclingBin sendToRecyclingBin(RecyclingBin recyclingBin, File corruptFile) {
		File[] corruptFileArray = recyclingBin.getCorruptFileArray();
		int numOfCorruptFiles=corruptFileArray.length;
		File[] newCorruptFileArray = new File[numOfCorruptFiles+1];
		corruptFile.setCurrentStage(CurrentStage.NotOwned);
		for (int i=0;i<numOfCorruptFiles;i++) {
			newCorruptFileArray[i] = corruptFileArray[i];
		}
		newCorruptFileArray[numOfCorruptFiles] = corruptFile;
		recyclingBin.setCorruptFileArray(newCorruptFileArray);
		System.out.println("The file "+corruptFile.getName()+" has been sent to the Recycling Bin."+"\n"+"The bits invested will not be reinbursed and the file cannot be bought by landing on it."+"\n"+"The only way to retrieve the file is to complete the memory game after landing on the Recycling Bin."+"\n"+"Take a note of the name for "+corruptFile.getName()+" as you will need to enter the name in full to retrieve it."+"\n"+"Beware however, as any player can play the Memory Game, and any player can take this file.");
		return recyclingBin;
	}
	
	/* Takes a random file from the user
	 * @param user - Player who will be losing a file
	 * @param recyclingBin - Object of the RecyclingBin class where the users file will be going
	 * @return recyclingBin - The updated Object of the RecyclingBin class
	 * @author Scott McDonald
	 */
	public RecyclingBin loseFile(Player user, RecyclingBin recyclingBin) {
		if ((user.getFilesOwned()).length >=1) {
			File[] playerFiles = user.getFilesOwned();
			Random rand = new Random();
			int upperbound = playerFiles.length;
			int ranNum = rand.nextInt(upperbound);
			File corruptedFile = playerFiles[ranNum];
			int numOfPlayerFiles = playerFiles.length;
			File[] tempArray = new File[numOfPlayerFiles-1];
			
			//gets index
			int index = -1; 
			for (int i=0;i<numOfPlayerFiles;i++) {
				if (playerFiles[i].equals((corruptedFile.getName()))) {
					index = i;
					break;
				}
			}

			//removing the element
			for (int i=0, k=0; i < numOfPlayerFiles; i++) {
				if (i==ranNum) {
					i++;
					if(i==numOfPlayerFiles) {
						break;
					}
				}
				tempArray[k] = playerFiles[i];
				k++;
			}
			//updates player files
			user.setFilesOwned(tempArray);
			recyclingBin = sendToRecyclingBin(recyclingBin, corruptedFile); //sends file to recycling bin
		}
		else {
			System.out.println("You have no files to corrupt.");
		}
		return recyclingBin;
	}
}
