package Classes;

public enum CurrentStage {
	NotOwned,
	Downloaded,
	Setup1,
	Setup2,
	Setup3,
	Installed
}
