package Classes;

public class Dice {
	private int rolledValue;
	
	public Dice(int rolledValue) {
		this.rolledValue = rolledValue;
	}
	
	/* gets a random number in the range of the to parameters 
	 * @param min - minimum number the random number could be
	 * @param max - maximum number the random number could be 
	 * @return randomNumber
	 * @author Conor Nugent
	 */
	public int getRandomNumber(int min, int max) {
		return (int) ((Math.random() * (max - min)) + min);
	}
	
	/* Act of rolling the dice in game
	 * @return rolledValue - a random number between 1 and 6
	 * @author Conor Nugent
	 */
	public int rollDice() {
		rolledValue = getRandomNumber(1, 6);
		return rolledValue;
	}
}
