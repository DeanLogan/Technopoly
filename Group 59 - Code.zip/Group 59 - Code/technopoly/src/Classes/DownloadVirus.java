package Classes;

public class DownloadVirus extends Location{
	private byte severityOfVirus;
	
	public DownloadVirus(String name, byte position, byte severityOfVirus) {
		super(name, position);
		this.severityOfVirus = severityOfVirus;
	}

	/* Sends the user to safe mode for the length of time denoted by severityOfVirus and increments severityOfVirus for the next user
	 * @param user - Player being sent to safeMode
	 * @param safeMode - the SafeMode object that the user will be sent to
	 * @return safeMode - returns the safeMode object with the updated attributes
	 * @author JB Higgins 
	 */
	public SafeMode downloadingVirus(Player user, SafeMode safeMode) {
		setSeverityOfVirus(getSeverityOfVirus());
		System.out.println(user.getName() + ", a virus has been detected in your directory.\nYou will now be moved to Safe Mode.");
		
		safeMode.goToSafeMode(user, severityOfVirus);
		
		return safeMode;
	}
	
	//standard getters and setters
	public byte getSeverityOfVirus() {
		try {
			severityOfVirus++; //increments the severityOfVirus
		} catch(Exception e) {
			return severityOfVirus;
		}
		return severityOfVirus;
	}

	public void setSeverityOfVirus(byte severityOfVirus) {
		this.severityOfVirus = severityOfVirus;
	}
}
