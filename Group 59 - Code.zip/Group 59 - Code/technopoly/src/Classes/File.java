package Classes;

import java.util.Random;
import java.util.Scanner;

public class File extends Location{
	private int downloadSpaceRequired;
	private int setupSpaceRequired;
	private int installationSpaceRequired;
	private CurrentStage currentStage;
	private FileType fileType;
	private int tempFileStorageSpaceDownload;
	private int tempFileStorageSpaceSetup;
	private int tempFileStorageSpaceInstallation;
	
	//maybe change currentStage and fileType to enums
	public File(String name, byte position, int downloadSpaceRequired, int setupSpaceRequired, int installationSpaceRequired, CurrentStage currentStage, 
			FileType fileType, int tempFileStorageSpaceDownload, int tempFileStorageSpaceSetup, int tempFileStorageSpaceInstallation) {
		super(name, position);
		this.downloadSpaceRequired = downloadSpaceRequired;
		this.setupSpaceRequired = setupSpaceRequired;
		this.installationSpaceRequired = installationSpaceRequired;
		this.currentStage = currentStage;
		this.fileType = fileType;
		this.tempFileStorageSpaceDownload = tempFileStorageSpaceDownload;
		this.tempFileStorageSpaceSetup = tempFileStorageSpaceSetup;
		this.tempFileStorageSpaceInstallation = tempFileStorageSpaceInstallation;
	}
	
	/* Starts the brute force mini game (whenever a user lands on a file owned by someone else)
	 * @param questionsAndAnswers - a String[][] of both the question and the answer of all possible questions
	 * @param usedQuestions - a String[] of all questions that have already been asked and answered correctly
	 * @param user - the Player who has landed on the file
	 * @param owner - the Player who owns the file
	 * @return usedQuestions - the updated usedQuestions array
	 * @author Dean Logan
	 */
	public String[] playBruteForce(String[][] questionsAndAnwsers, String[] usedQuestions, Player user, Player owner) { //return usedQuestions instead of boolean also add owner and user to this
		Random rand = new Random();
		int questionIndex = 0;
		String[] question;
		//checks if all the questions have already been asked
		if(usedQuestions.length < questionsAndAnwsers.length) {
			//checks usedQuestions array to make sure the same question isn't asked twice
			while(true) {
				boolean found = false;
				questionIndex = rand.nextInt(questionsAndAnwsers.length);
				for(int i=0; i<usedQuestions.length; i++) {
					if(questionsAndAnwsers[questionIndex][0].equals(usedQuestions[i])) {
						found = true;
						break;
					}
				}
				if (!found) {
					question = questionsAndAnwsers[questionIndex]; //sets the question to be asked
					break; 
				}
			}
		}
		//this will reset the usedQuestion array if all questions have been asked
		else {
			String[] temp1 = {};
			usedQuestions = temp1;
			questionIndex = rand.nextInt(questionsAndAnwsers.length);
			question = questionsAndAnwsers[questionIndex];
		}
		
		System.out.println("The password hint is: ");
		System.out.println(question[0]);
		
		boolean correctAnswer = false;
		//loops for the number of tries the player has to answer the question
		for(int tries=5; tries>0; tries--) {
			System.out.print("Please enter password: ");
			Scanner input = new Scanner(System.in);
			String ans = input.nextLine();
			ans = ans.replaceAll(" ", "");
			
			//makes sure if the question is a true or false one the user only gets 1 attempt to answer the question
			if("true".compareToIgnoreCase(question[1].replaceAll(" ", "")) == 0 || "false".compareToIgnoreCase(question[1].replaceAll(" ", "")) == 0) {
				tries = 1;
			}
			
			//if the user enters the correct answer
			if(ans.compareToIgnoreCase(question[1].replaceAll(" ", "")) == 0) {
				System.out.println("Well done the password is correct you no longer have to pay the owner of this file");
				correctAnswer = true;
				//adds the question that was just asked into the used question array
				int usedQuestionLen = usedQuestions.length;
				String[] temp2 = new String[usedQuestionLen+1];
				for(int j=0; j<usedQuestionLen; j++) {
					temp2[j] = usedQuestions[j];
				}
				temp2[usedQuestionLen] = question[0];
				usedQuestions = temp2;
				break;
			}
			else {
				System.out.println("You have "+(tries-1)+" attempts remaining");
			}
		}
		
		if(!correctAnswer) {
			System.out.println("You have ran out of trys");
			chargeUser(user, owner); //charges the user if they failed to answer the question correctly
		}
		return usedQuestions;
	}
	
	/* This will give the current file to the user
	 * @param user - Player to be given the file to
	 * @author Dean Logan
	 */
	public void downloadingFile(Player user) {
		int userStorageSpace = user.getStorageSpace();
		//makes sure the user can afford to download the file
		if(userStorageSpace >= downloadSpaceRequired) {
			user.setStorageSpace(userStorageSpace-downloadSpaceRequired);
			//adds this file to the users array of filesOwned
			File[] filesOwned = user.getFilesOwned();
			int numOfFilesOwned = filesOwned.length;
			File[] tempArray = new File[numOfFilesOwned+1];
			for(int i=0; i<numOfFilesOwned; i++) {
				tempArray[i] = filesOwned[i];
			}
			tempArray[numOfFilesOwned] = this;
			user.setFilesOwned(tempArray);
			currentStage = CurrentStage.Downloaded; //updates the stage of this file
			System.out.println("You have successfully downloaded "+this.getName());
		}
		else {
			System.out.println("You do not have enough space to download "+this.getName());
		}
	}
	
	/* Upgrades this file to the Install stage 
	 * @param user - The owner of the file
	 * @author Dean Logan
	 */
	public void installingFile(Player user) {
		int userStorageSpace = user.getStorageSpace();
		//makes sure the user can afford to upgrade the file
		if(userStorageSpace >= installationSpaceRequired) {
			//makes sure the file is currently at the correct stage before it can move onto install
			if(currentStage == CurrentStage.Setup3) {
				user.setStorageSpace(userStorageSpace-installationSpaceRequired);
				currentStage = CurrentStage.Installed;
				System.out.println("You have successfully installed the file "+this.getName());
			}
			else {
				System.out.println("Current Stage must be at Setup3");
			}
		}
		else {
			System.out.println("You do not have enough space to install "+this.getName());
		}
	}
	
	/* Upgrades this file through the Setup stages
	 * @param user - The owner of the file
	 * @author Dean Logan
	 */
	public void setupProcess(Player user) {
		//makes sure the user owns all of the files of the same type before upgrading from Download to Setup1
		int sameFileTypesFound = 0;
		int numOfFileTypes = 3;
		if(fileType == FileType.mpp || fileType == FileType.one) {
			numOfFileTypes = 2;
		}
		File[] userOwnedFiles = user.getFilesOwned();
		
		for(int i=0; i<userOwnedFiles.length; i++) {
			if(userOwnedFiles[i].getFileType() == fileType) {
				sameFileTypesFound++;
			}
		}

		if(sameFileTypesFound < numOfFileTypes) {
			System.out.println("You do not own all of the file types of this file");
			return;
		}
		
		//makes sure the user can afford to upgrade this file to the next stage
		int userStorageSpace = user.getStorageSpace();
		if(userStorageSpace >= setupSpaceRequired) {
			//checks to see what the currentStage of this file is to ensure it is updgraded to the correct next stage. E.g ensures you can't go from Setup1 straight to Setup3
			if(currentStage != CurrentStage.Setup3 && currentStage != CurrentStage.NotOwned && currentStage != CurrentStage.Installed) {
				user.setStorageSpace(userStorageSpace-setupSpaceRequired);
				if(currentStage == CurrentStage.Downloaded) {
					currentStage = CurrentStage.Setup1;
					System.out.println("You have successfully progressed to stage 1 in the setup process for the file "+this.getName());
				}
				else if(currentStage == CurrentStage.Setup1) {
					currentStage = CurrentStage.Setup2;
					System.out.println("You have successfully progressed to stage 2 in the setup process for the file "+this.getName());
				}
				else if(currentStage == CurrentStage.Setup2) {
					currentStage = CurrentStage.Setup3;
					System.out.println("You have successfully progressed to stage 3 in the setup process for the file "+this.getName());
				}
			}
			else {
				System.out.println("The file is not at the correct stage for this operation");
			}
		}
		else {
			System.out.println("You do not have enough space to continue the setup process for "+this.getName());
		}
	}
	
	/* Allows you to see who owns this file
	 * @param playerArray - an array of Player objects
	 * @return either null if no Player owns the file or returns the Object of the Player who owns the file
	 * @author Dean Logan
	 */
	public Player checkWhoOwnsFile(Player[] playerArray) { 
		for(int i=0; i<playerArray.length; i++) {
			File[] filesOwned = playerArray[i].getFilesOwned();
			for(int j=0; j<filesOwned.length; j++) {
				if(filesOwned[j].equals(this) && this.currentStage != currentStage.NotOwned) {
					return playerArray[i];
				}
			}
		}
		return null;
	}
	
	/* Charges the user a certain amount based on what stage this file is currently at. Then gives these bits to the owner of the file
	 * @param user - Player who has landed on the file
	 * @param owner - Player who owns this file
	 * @author Dean Logan
	 */
	public void chargeUser(Player user, Player owner) {
		int price = 0;
		int ownersBits = owner.getStorageSpace();
		int usersBits = user.getStorageSpace();
		
		if(currentStage == CurrentStage.Downloaded) {
			price = tempFileStorageSpaceDownload;
		}
		else if(currentStage == CurrentStage.Setup1) {
			price = tempFileStorageSpaceSetup;
		}
		else if(currentStage == CurrentStage.Setup2) {
			price = tempFileStorageSpaceSetup*2;
		}
		else if(currentStage == CurrentStage.Setup3) {
			price = tempFileStorageSpaceSetup*3;
		}
		else if(currentStage == CurrentStage.Installed) {
			price = tempFileStorageSpaceInstallation;
		}
		//ensures that the owner only gets the remaining bits of the user if the user does not have enough bits to pay the full amount
		int payAmount = usersBits-price;
		if(payAmount <= 0) {
			payAmount = usersBits;
			System.out.println(user.getName()+" you are now out of bits.");
			user.setStorageSpace(0);
		}
		else {
			user.setStorageSpace(payAmount);
		}
		System.out.println(user.getName()+ ", you have given "+owner.getName()+" "+payAmount+" bits");
		owner.setStorageSpace(ownersBits+payAmount);
	}
	
	//standard getters and setters
	public CurrentStage getCurrentStage() {
		return currentStage;
	}

	public void setCurrentStage(CurrentStage currentStage) {
		this.currentStage = currentStage;
	}

	public FileType getFileType() {
		return fileType;
	}

	public void setFileType(FileType fileType) {
		this.fileType = fileType;
	}

	public int getDownloadSpaceRequired() {
		return downloadSpaceRequired;
	}

	public int getSetupSpaceRequired() {
		return setupSpaceRequired;
	}

	public int getInstallationSpaceRequired() {
		return installationSpaceRequired;
	}
}
