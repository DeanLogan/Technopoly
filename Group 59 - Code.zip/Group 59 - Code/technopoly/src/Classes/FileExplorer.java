package Classes;

import java.util.Scanner;

public class FileExplorer extends Location{
	private int fare;
	
	public FileExplorer(String name, byte position, int fare) {
		super(name, position);
		this.fare = fare;
	}
	
	/* Allows the user to select which file (if any) to move to, from a menu which is displayed within this method 
	 * @param user - Player who will be moved (if they chose) to one of the files they own
	 * @author Scott McDonald
	 */
	public void selectOption(Player user) {
		Classes.File[] playerFiles = user.getFilesOwned();
		int playerFilesLen = playerFiles.length;
		Classes.File destinationLocation = null;
		if (playerFilesLen >= 1) {
			while(true) {
				System.out.println("\n"+user.getName()+", please choose from the list below: ");
				for (int i=0; i< playerFilesLen; i++) {
					System.out.println((i+1)+". "+playerFiles[i].getName()+" - "+playerFiles[i].getCurrentStage()); //gets names of files and numbers them - figured I should add in the state the files are in so that the user can see what files they can build on, etc
				}
				
				System.out.println((playerFilesLen+1)+". Back");
				System.out.println("");
				System.out.print("Please select a file: ");
				Scanner input = new Scanner(System.in);
				String option = input.nextLine();
				option = option.replace(" ","");
				
				if(option.compareToIgnoreCase("Back") == 0 || option.compareToIgnoreCase(String.valueOf(playerFilesLen+1)) == 0) {
					System.out.println("Exiting Menu");
					break;
				}
				
				try {
					int optionNum = Integer.valueOf(option);
					if(optionNum <= playerFilesLen) {
						destinationLocation = playerFiles[optionNum-1];
					}
					else {
						System.out.println("Please select one of the files above");
					}
				}
				catch (NumberFormatException ex){
					for(int i=0; i<playerFilesLen; i++) {
						if(playerFiles[i].getName().replace(" ", "").compareToIgnoreCase(option) == 0) {
							destinationLocation = playerFiles[i];
							break;
						}
					}
					if(destinationLocation == null) {
						System.out.println("Please select one of the files above");
					}
				}
				
				if(destinationLocation != null ) {
					System.out.println("The fare will be "+fare+"  bits."+"\n"+"Are you comfortable paying? (y/n): ");
					String opt = input.nextLine();
					opt = opt.replaceAll(" ","");

					if(opt.compareToIgnoreCase("y") == 0 || opt.compareToIgnoreCase("Yes") == 0) {
						if(fare != 0) {
							movePlayer(user, destinationLocation);
						}
					}
					System.out.println("Exiting the menu.");
					break;
				}
				else {
					System.out.println("Please enter a corresponding number of the full name and type of the location.");
				}
			}
		}
		else {
			System.out.println("You have no files to travel to.");
		}
	}

	/* Checks to see if the user owns a utility card which can be used to dodge the fare of using the file explorer
	 * @param user - Player to check if they have a util card or not
	 * @author Scott McDonald
	 */
	public void utilCardCheck(Player user) {
		if((user.getUtilPass())>=1) {
			user.setStorageSpace(((user.getStorageSpace())-fare)+200);
			user.setUtilPass((byte) (user.getUtilPass() - 1));
			System.out.println("You have used a Utility pass to get 200 when passing Go.");
			System.out.println("You now have " + user.getUtilPass() + " Utility passes remaining.");
		}
		else {
			user.setStorageSpace((user.getStorageSpace())-fare);
			System.out.println("You don't have a Utility pass." + "\n" + "Therefore, you don't get the 200 bits passing Go.");
		}
	}
	
	/* Moves the user to the selected location
	 * @param user - Player being moved
	 * @location - Location being moved to
	 * @author Scott McDonald;
	 */
	public void movePlayer(Player user, File location) {
		int playerStorageSpace = user.getStorageSpace();

		if(playerStorageSpace >= fare) {
			user.setStorageSpace(playerStorageSpace-fare);
			int oldPosition = user.getPositionAt();
			int newPosition = location.getPosition();
			System.out.print("You have moved from "+oldPosition);
			user.setPositionAt(newPosition);
			System.out.println(" to "+user.getPositionAt() + ".");
			if(oldPosition>newPosition) {
				utilCardCheck(user);
			}
			System.out.println("Your new balance is "+user.getStorageSpace() + ".");
			}
		else {
			System.out.println("You do not have enough bits for this action.");
		}
	}
	
	
	
}
