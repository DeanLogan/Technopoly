package Classes;

public enum FileType {
	pdf,
	docx,
	xlsx,
	pptx,
	one,
	mpp,
	mp4,
	svg
}
