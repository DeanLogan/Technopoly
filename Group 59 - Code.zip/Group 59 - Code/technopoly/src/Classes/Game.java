package Classes;

//maybe we should just make this our main class
//don't think we need any getters and setter for this class

import java.util.Scanner;

//import jdk.internal.joptsimple.internal.Classes; - I have commented this out and no errors have come up so i assume this isnt needed

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random; //remove when rollDice is implemented

public class Game {
	private Player[] playerArray;
	private Dice diceOne;
	private Dice diceTwo;
	private Location[] locationArray;
	private Player currentPlayer;
	private String[][] questionsAndAnswers;
	private String[] usedQuestions = {};
	private String gameSave;

	public Game() { //maybe call the initialise methods in the constructor 
		this.diceOne = null;
		this.diceTwo = null;
		this.gameSave = null;
	}
	
	/* This will save the current game. Does this by writing all of the necessary information to a text file which will be stored locally
	 * @author Dean Logan
	 */
	public void savingGame() {
		String path = "src\\saveGame\\";
		//gets all of the files within the saveGame folder to ensure the files are numbered correctly
		String[] files = txtFilesInDirectory(path);
		if(gameSave == null) {
			path += "game"+(files.length+1)+".txt";
		}
		else {
			boolean found = false;
			gameSave += ".txt";
			for(int i=0; i<files.length; i++) {
				System.out.println("gameSave "+gameSave+" fileName "+files[i]);
				if(gameSave.equals(files[i])) {
					found = true;
					break;
				}
			}
			if(found) {
				path += gameSave;
			}
			else {
				System.out.println("The game file was not found therefore a new save will be created");
				path += "game"+(files.length+1)+".txt";
			}
		}
		//creates the file for the information to be written to 
		PrintWriter myPw = null;
		try {
			myPw = new PrintWriter(path);
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found");
		}
		
		//collecting of all the information from the game
		String infoOfGame = "";
		
		infoOfGame += playerArray.length; //adding in the number of players 
		
		infoOfGame += System.lineSeparator()+currentPlayer.getId(); //adding the id of the currnet player 
		
		infoOfGame += System.lineSeparator()+ ((DownloadVirus) locationArray[30]).getSeverityOfVirus(); //adding the severityOfVirus
		
		//adds all of the players positions to the String
		infoOfGame += System.lineSeparator();
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += playerArray[i].getPositionAt();
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players storage space to the String
		infoOfGame += System.lineSeparator();
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += playerArray[i].getStorageSpace();
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players util pass amount to the String
		infoOfGame += System.lineSeparator();
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += playerArray[i].getUtilPass();
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players id to the String
		infoOfGame += System.lineSeparator();
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += playerArray[i].getId();
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players time in safe mode to the String
		infoOfGame += System.lineSeparator();
		SafeMode safeMode = (SafeMode) locationArray[10];
		Player[] playersInSafeMode = safeMode.getPlayersInSafeMode();
		byte[] timeInSafeMode = safeMode.getTimeSpentInSafeMode();
		for(int i=0; i<playerArray.length; i++) {
			if(safeMode.searchPlayerInSafeMode(playerArray[i])) {
				for(int j=0; j<playersInSafeMode.length; j++) {
					if(playerArray[i].equals(playersInSafeMode[j])) {
						infoOfGame += timeInSafeMode[j];
					}
				}
			}
			else {
				infoOfGame += "0";
			}
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players names to the String
		infoOfGame += System.lineSeparator();
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += playerArray[i].getName();
			//ensures there is no , at the end of the line
			if(i != playerArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		//adds all of the players files into the String
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += System.lineSeparator();
			Classes.File[] filesOwned = playerArray[i].getFilesOwned();
			for(int j=0; j<filesOwned.length; j++) {
				infoOfGame += filesOwned[j].getName();
				//ensures there is no , at the end of the line
				if(j != filesOwned.length-1) {
					infoOfGame += ",";
				}
			}
		}
		
		//adds the stage of each of the players files to the String
		for(int i=0; i<playerArray.length; i++) {
			infoOfGame += System.lineSeparator();
			Classes.File[] filesOwned = playerArray[i].getFilesOwned();
			for(int j=0; j<filesOwned.length; j++) {
				infoOfGame += filesOwned[j].getCurrentStage();
				//ensures there is no , at the end of the line
				if(j != filesOwned.length-1) {
					infoOfGame += ",";
				}
			}
		}
		
		//adds the corruptFileArray to the String ((RecyclingBin) locationArray[20]).getCorruptFileArray();
		Classes.File[] corruptFileArray = ((RecyclingBin) locationArray[20]).getCorruptFileArray();
		
		infoOfGame += System.lineSeparator();
		for(int i=0; i<corruptFileArray.length; i++) {
			infoOfGame += corruptFileArray[i].getName();
			//ensures there is no , at the end of the line
			if(i != corruptFileArray.length-1) {
				infoOfGame += ",";
			}
		}
		
		System.out.println("");
		System.out.println("The game has been successfully saved");
		System.out.println("");
		
		//writes the information to the text file
		myPw.print(infoOfGame);
		myPw.println("");
		myPw.close();
		
		try {
			titleScreen();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/* Displays a menu of all the saved games found on the machine
	 * @author Dean Logan
	 */
	public void savedGames() {
		String[] games = txtFilesInDirectory("src\\saveGame\\"); //gets the file name of all the saved games

		//checks to see if there are any saved games
		if(games == null) {
			System.out.println("");
			System.out.println("There are no saved games");
			System.out.println("");
			try {
				titleScreen();
			} catch (FileNotFoundException e) {
				System.out.println("File not found");
			}
		}
		else {
			System.out.println("");
			System.out.println("Please select a game to continue with");
			//loop for validation
			while(true) {
				//prints all of the saved games to the user
				for(int i=1; i<games.length+1; i++) {
					System.out.println(i+"."+" Game "+i);
				}
				System.out.println((games.length+1)+". Back");
				
				//gets the users input
				System.out.println("");
				System.out.print("Please select an option: ");
				Scanner input = new Scanner(System.in);
				String option = input.nextLine();
				option = option.replaceAll(" ","");
				
				//checks to see if the user has entered the option to go back
				if(option.compareToIgnoreCase("Back") == 0 || option.compareToIgnoreCase(String.valueOf(games.length+1)) == 0) {
					try {
						titleScreen();
						break;
					} catch (FileNotFoundException e) {
						System.out.println("File not found");
						break;
					}
				}
				//checks to see if the user has entered a valid option
				try {
					//checks if the user has entered the number of the option they wish to select
					int optionNum = Integer.valueOf(option);
					if(optionNum <= games.length+1 && optionNum > 0) {
						loadingSavedGame("game"+optionNum);
					}
					else {
						System.out.println("");
						System.out.println("Please select one of the game saves above by either entering the number of the save or the name of the save");
						System.out.println("");
					}
				}
				//checks if the user has entered the name of the option they wish to select
				catch (NumberFormatException ex) {
					String gameSelected = "";
					for(int i=0; i<games.length; i++) {
						if(games[i].replaceAll(" ", "").compareToIgnoreCase(option+".txt") == 0) {
							gameSelected = "game"+(i+1);
							loadingSavedGame(gameSelected);
							break;
						}
					}
					if(gameSelected == "") {
						System.out.println("");
						System.out.println("Please select one of the files above");
						System.out.println("");
					}
				}
			}
		}
	}
	
	/* Gets a list of all the text files within the given directory which contains the word "game" at the start
	 * @param directory - String of the directory of the folder which is to be searched
	 * @return fileNames - String[] of all the file names found, if no file names are found it returns null
	 * @author Dean Logan
	 */
	public String[] txtFilesInDirectory(String directory) {
		try {
			File folder = new File(directory);
			File[] listOfFiles = folder.listFiles();
			String fileNames = "";

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					if(listOfFiles[i].getName().contains(".txt") && listOfFiles[i].getName().substring(0,4).equals("game")) {
						fileNames += listOfFiles[i].getName() +",";
					}
				}
			}
			if(fileNames.equals("")) {
				return null;
			}
			return fileNames.split(",");
		}
		catch(Exception e) {
			return null;
		}
	}
	
	/* This will load a saved state of the game. Does this by reading the information in the selected text file then collects this information and initialises the game 
	 * @param selectedGame - The name of the game which was selected by the user
	 * @author Dean Logan
	 */
	public void loadingSavedGame(String selectedGame) {
		boolean error = false;
		String path = "src\\saveGame\\";
		path += selectedGame+".txt";
		gameSave = selectedGame;
		System.out.println(path);
		File gameSavePath = new File(path); 
		try {
			Scanner gameSave = new Scanner(gameSavePath);
			
			//initialising variables which are used later on
			int numOfPlayers = 0;
			int currentPlayerId = 0;
			byte severityOfVirus = 0;
			int[] playerPositions = null;
			int[] playerStorageSpace = null;
			int[] playerUtilPassNum = null;
			byte[] playerId = null;
			byte[] playersTimeInSafeMode = null;
			
			try {
				numOfPlayers = Integer.parseInt(gameSave.nextLine()); //getting the total number of players
				currentPlayerId = Integer.parseInt(gameSave.nextLine()); //getting the id of the current player
				severityOfVirus = (byte) Integer.parseInt(gameSave.nextLine()); //getting the severityOfVirus 
				
				//getting each players position, storage space, number of util passes and id
				String[] playerPositionsString = gameSave.nextLine().split(",");
				String[] playerStorageSpaceString = gameSave.nextLine().split(",");
				String[] playerUtilPassNumString = gameSave.nextLine().split(",");
				String[] playerIdString = gameSave.nextLine().split(",");
				String[] playersTimeInSafeModeString = gameSave.nextLine().split(",");
				playerPositions = new int[numOfPlayers];
				playerStorageSpace = new int[numOfPlayers];
				playerUtilPassNum = new int[numOfPlayers];
				playerId = new byte[numOfPlayers];
				playersTimeInSafeMode = new byte[numOfPlayers];
				
				//sets each of the values to their correct data type
				for(int i=0; i<numOfPlayers; i++) {
					playerPositions[i] = Integer.parseInt(playerPositionsString[i]);
					playerStorageSpace[i] = Integer.parseInt(playerStorageSpaceString[i]);
					playerUtilPassNum[i] = Integer.parseInt(playerUtilPassNumString[i]);
					playerId[i] = (byte) Integer.parseInt(playerIdString[i]);
					playersTimeInSafeMode[i] = (byte) Integer.parseInt(playersTimeInSafeModeString[i]);
					
					if(playersTimeInSafeMode[i] < 0 || playerId[i] < 0 || playerId[i] > (numOfPlayers-1) || numOfPlayers > 9 || playerUtilPassNum[i] < 0) {
						error = true;
					}
					else if(playerId[i] < 0 && playerStorageSpace[i] >= 0) {
						error = true;
					}
				}
			}
			catch(Exception e) {
				error = true;
			}
			String[] playerNames = gameSave.nextLine().split(","); //getting all of the players names
			
			//getting each of the players files
			String[] playersFiles = new String[numOfPlayers];
			for(int i=0; i<numOfPlayers; i++) {
				playersFiles[i] = gameSave.nextLine();
			}
			
			//getting each stage the files are at
			String[] fileStages = new String[numOfPlayers];
			for(int i=0; i<numOfPlayers; i++) {
				fileStages[i] = gameSave.nextLine();
			}
			
			//getting each file that is corrupt (in the corruptFileArray)
			String corruptFilesString = gameSave.nextLine();
			String[] corruptFiles = corruptFilesString.split(",");
			
			gameSave.close();
			
			if(!error) {
				playerArray = new Player[numOfPlayers]; //initalising the playerArray with length of the number of players
				
				initialiseLocations();
				initialiseDice();
				
				((DownloadVirus) locationArray[30]).setSeverityOfVirus(severityOfVirus);//sets the severityOfVirus
				
				//sets the corruptFileArray in recyclingBin
				Classes.File[] corruptFileArray = new Classes.File[corruptFiles.length];
				for(int i=0; i<corruptFileArray.length; i++) {
					for(int j=0; j<locationArray.length; j++) {
						//searches for the name of the file to make sure it exists before adding it to the corruptFileArray
						if(corruptFiles[i].compareToIgnoreCase(locationArray[j].getName()) == 0) {
							//makes sure nobody owns the file
							if (locationArray[j] instanceof Classes.File) {
								if(((Classes.File)locationArray[j]).getCurrentStage() == CurrentStage.NotOwned) {
									corruptFileArray[i] = (Classes.File) locationArray[j];
								}
							}
						}
					}
				}
				
				if(corruptFilesString == "") {
					Classes.File[] emptyFileArray = {};
					corruptFileArray = emptyFileArray;
				}
				((RecyclingBin) locationArray[20]).setCorruptFileArray(corruptFileArray);
					
				//loops for each one of the players
				for(int i=0; i<numOfPlayers; i++) {
					String[] files = playersFiles[i].split(",");
					String[] stageStringArray = fileStages[i].split(",");
					int filesFound = 0; //number of file names within the text document that exist in the system
					
					Classes.File[] filesOwned = new Classes.File[files.length];
					
					//loops for each file that the player owns
					for(int j=0; j<files.length; j++) {
						//loops through each location in the locationArray
						for(int x=0; x<locationArray.length; x++) {
							//searches for the name of the file the player owns within the location array
							if(files[j].compareToIgnoreCase(locationArray[x].getName()) == 0) {
								//checks what stage the file is at then sets the files stage
								String stageString = stageStringArray[j].replaceAll(" ","");
								CurrentStage stage = CurrentStage.Downloaded;
								if(stageString.equals("Downloaded")) {
									stage = CurrentStage.Downloaded;
								}
								else if(stageString.equals("Setup1")) {
									stage = CurrentStage.Setup1;
								}
								else if(stageString.equals("Setup2")) {
									stage = CurrentStage.Setup2;
								}
								else if(stageString.equals("Setup3")) {
									stage = CurrentStage.Setup3;
								}
								else if(stageString.equals("Installed")) {
									stage = CurrentStage.Installed;
								}
								filesFound++;
								((Classes.File)locationArray[x]).setCurrentStage(stage);
								filesOwned[j] = ((Classes.File)locationArray[x]);
							}
						}
						if(filesFound == 0) {
							Classes.File[] emptyFileArray = {}; //creates an empty array of type Classes.File
							filesOwned = emptyFileArray;
						}
					}
					//creates the player object
					Player player = new Player(playerNames[i], (byte)playerId[i], playerStorageSpace[i], filesOwned, (byte)playerUtilPassNum[i], playerPositions[i]);
					//checks if the user is in safe mode, and if they are puts them in safe mode
					if(playersTimeInSafeMode[i] != 0) {
						SafeMode safeMode = (SafeMode)locationArray[10];
						safeMode.goToSafeMode(player, playersTimeInSafeMode[i]);
					}
					
					playerArray[i] = player; 
					
					//sets the currentPlayer
					if(currentPlayerId == playerId[i]) {
						currentPlayer = player;
					}
				}
				
				System.out.println("");
				System.out.println("Your game will now continue");
				displayOptionsForPlayer();
			
			}
		}
		catch (Exception e) {
			error = true;
		}

		//if there is an error at any point during the loading process the game will stop loading and this message will be displayed to the user
		if(error) {
			gameSave = null;
			System.out.println("It appears the save you have selected has been corrupted. Please select a different save from the list below.");
			System.out.println("");
		}
	}
	
	/* Gets all the questions and answers from the file "QuestionsAndAnswersForBruteForceGame.csv" and puts them into a 2d String array called questionsAndAnswers
	 * @returns questionsAndAnswers - a String[][] of questions and answers for the brute force mini game
	 * @author Dean Logan
	 */
	public String[][] retrievingQuestionsAndAnswers() {
		File path = new File("src\\TextDocuments\\QuestionsAndAnswersForBruteForceGame.csv");
		try {
			Scanner questionsAndAnswersFile = new Scanner(path);
			//finds the number of questions in the file by looking for the word end
			int lines = 0;
			while(true) {
				String word = questionsAndAnswersFile.nextLine();
				if("end".equals(word)){
					break;
				}
				lines++;
			}
			questionsAndAnswersFile.close();
			//adds each line to the questionsAndAnswers attribute 
			questionsAndAnswers = new String[lines][2];
			questionsAndAnswersFile = new Scanner(path);

			for(int i=0; i<lines; i++) {
				String[] quAndAn =  questionsAndAnswersFile.nextLine().split(",");
				questionsAndAnswers[i][0] = quAndAn[0];
				questionsAndAnswers[i][1] = quAndAn[1];
			}
			questionsAndAnswersFile.close();
		}
		catch (FileNotFoundException e) {
			//if no file is found returns array of some quesitons and answers for the brute force mini game
			System.out.println("File not found");
			String[][] questionsAndAnswers = {{"In which part of your body would you find the cruciate ligament?", "Knee"},
					{"What is the name of the main antagonist in the Shakespeare play Othello?","Iago"},
					{"What element is denoted by the chemical symbol Sn in the periodic table?","Tin"},
					{"What is the name of the 1976 film about the Watergate scandal, starring Robert Redford and Dustin Hoffman?","All the President's Men"},
					{"How many of Henry VIII's wives were called Catherine?","3"}};
		}
		return questionsAndAnswers;
	}
	
	/* Allows the user to select how many players are in the game and then created the objects for these players
	 * @author Dean Logan
	 */
	public void initialisePlayers() {
		int numOfPlayers;
		Scanner input = new Scanner(System.in); // maybe make this an attribute
		
		//allows the user to enter in how many players are playing the game
		while(true) {
			System.out.println("");
			System.out.print("Please enter how many people will be playing the game: ");
			try {
				numOfPlayers = input.nextInt();
				if(numOfPlayers > 1 && numOfPlayers < 10) {
					playerArray = new Player[numOfPlayers];
					input.nextLine();
					break;	
				}
				else {
					System.out.println("");
					System.out.println("Please enter a number in the range of 2-9");
					input.nextLine();
				}
			}
			catch (Exception e) {
				System.out.println("");
				System.out.println("Please enter an integer for the number of players");
				input.nextLine();
			}
		}
		
		//gets the name for each player and ensures the same name is not used twice
		boolean nameTaken;
		for(int i=0; i<numOfPlayers; i++) {
			String name = "";
			while(true) {
				nameTaken = false;
				System.out.print("Enter player " + (i+1) + " name: ");
				name = input.nextLine();
				if(name.replace(" ", "").equals("")) {
					System.out.println("");
					System.out.println("Please enter something for the players name");
					System.out.println("");
				}
				else if(name.length() > 10) {
					System.out.println("");
					System.out.println("Name must be less than 10 characters long");
					System.out.println("");
				}
				else {
					for(int j=0; j<numOfPlayers; j++) {
						if(playerArray[j] != null) {
							if(name.replaceAll(" ", "").equals(playerArray[j].getName().replaceAll(" ", ""))) {
								nameTaken = true;
								break;
							}	
						}
					}
					if(!nameTaken) {
						break;
					}
					else {
						System.out.println("");
						System.out.println("You cannot enter the same name as another player");
						System.out.println("");
					}
				}
			}
			//creates the player object for each player
			Classes.File[] filesOwned = {};
			Player player = new Player(name, (byte)i, 1000, filesOwned, (byte)0, 0);
			playerArray[i] = player;	
		}
	}
	
	/* Creates both of the dice objects 
	 * @author Dean Logan
	 */
	public void initialiseDice() {
		diceOne = new Dice(0);
		diceTwo = new Dice(0);
	}
	
	/* Creates all of the location objects needed for the game and adds them all to the locationArray
	 * @author Dean Logan
	 */
	public void initialiseLocations() {		

		String[] games = {"tictactoe", "wordle", "hangMan"};
		Player[] playersInSafeMode = new Player[playerArray.length]; //should initialise this array with length of numOfPlayers
		byte[] timeSpentInSafeMode = new byte[playerArray.length];
		Classes.File[] corruptFileArray = {};
		questionsAndAnswers = retrievingQuestionsAndAnswers();
		
		Go go = new Go("Go", (byte)0, 200);
		Classes.File softwareProcessMPP = new Classes.File("Software Process.mpp", (byte)1, 60, 40, 100, CurrentStage.NotOwned, FileType.mpp, 20, 40, 60);
		CorruptFile corruptFile1 = new CorruptFile("Corrupt File", (byte)2);
		Classes.File practicalProjectManagementMPP = new Classes.File("Practical Project Management.mpp", (byte)3, 60, 40, 100, CurrentStage.NotOwned, FileType.mpp, 20, 40, 60);
		Utility util1 = new Utility("Utility", (byte)4);
		FileExplorer fileExplorer1 = new FileExplorer("File Explorer 1", (byte)5, 50);
		
		Classes.File scrumDOCX = new Classes.File("SCRUM.docx", (byte)6, 100, 80, 160, CurrentStage.NotOwned, FileType.docx, 30, 60, 80);
		Captcha captcha1 = new Captcha("Captcha", (byte)7, games);
		Classes.File userStoriesDOCX = new Classes.File("User Stories.docx", (byte)8, 100, 80, 160, CurrentStage.NotOwned, FileType.docx, 30, 60, 80);
		Classes.File useCasesAndStoriesDOCX = new Classes.File("Use Cases and Stories.docx", (byte)9, 100, 80, 160, CurrentStage.NotOwned, FileType.docx, 30, 60, 80);
		
		SafeMode safeMode = new SafeMode("Safe Mode", (byte)10, playersInSafeMode, timeSpentInSafeMode);
		Classes.File softwareVerifcationSVG = new Classes.File("Software Verifcation.svg", (byte)11, 160, 100, 200, CurrentStage.NotOwned, FileType.svg, 50, 70, 90);
		Utility util2 = new Utility("Utility", (byte)12);
		Classes.File requirementsEngineeringSVG = new Classes.File("Requirements Engineering.svg", (byte)13, 160, 100, 200, CurrentStage.NotOwned, FileType.svg, 50, 70, 90);
		Classes.File requirementsEngineeringAnalysisSVG = new Classes.File("Requirements Engineering Analysis.svg", (byte)14, 160, 100, 200, CurrentStage.NotOwned, FileType.svg, 50, 70, 90);
		FileExplorer fileExplorer2 = new FileExplorer("File Explorer 2", (byte)15, 50);
		
		Classes.File umlClassDiagramsPPTX = new Classes.File("UML Class Diagrams.pptx", (byte)16, 200, 140, 250, CurrentStage.NotOwned, FileType.pptx, 100, 80, 130);
		CorruptFile corruptFile2 = new CorruptFile("Corrupt File", (byte)17);
		Classes.File softwareImplementationPPTX = new Classes.File("Software Implementation.pptx", (byte)18, 200, 140, 250, CurrentStage.NotOwned, FileType.pptx, 100, 80, 130);
		Classes.File designDosAndDontsPPTX = new Classes.File("Design Dos and Don'ts.pptx", (byte)19, 200, 140, 250, CurrentStage.NotOwned, FileType.pptx, 100, 80, 130);
		RecyclingBin recycleBin = new RecyclingBin("Recycle Bin", (byte)20, corruptFileArray);
		
		Classes.File uiPatternsPDF = new Classes.File("UI Patterns.pdf", (byte)21, 250, 200, 300, CurrentStage.NotOwned, FileType.pdf, 130, 100, 150);
		Captcha captcha2 = new Captcha("Captcha", (byte)22, games);
		Classes.File softwareAssurancePDF = new Classes.File("Software Assurance.pdf", (byte)23, 250, 200, 300, CurrentStage.NotOwned, FileType.pdf, 130, 100, 150);
		Classes.File designQualityPDF = new Classes.File("Design Quality.pdf", (byte)24, 250, 200, 300, CurrentStage.NotOwned, FileType.pdf, 130, 100, 150);
		FileExplorer fileExplorer3 = new FileExplorer("File Explorer 3", (byte)25, 50);
		
		Classes.File pairProgrammingMP4 = new Classes.File("Pair Programming.mp4", (byte)26, 300, 200, 360, CurrentStage.NotOwned, FileType.mp4, 150, 130, 190);
		Classes.File sprintRetrospectiveMP4 = new Classes.File("Sprint Retrospective.mp4", (byte)27, 300, 200, 360, CurrentStage.NotOwned, FileType.mp4, 150, 130, 190);
		Utility util3 = new Utility("Utility", (byte)28);
		Classes.File agileManifestoMP4 = new Classes.File("Agile Manifesto.mp4", (byte)29, 300, 200, 360, CurrentStage.NotOwned, FileType.mp4, 150, 130, 190);
		DownloadVirus downloadVirus = new DownloadVirus("Download Virus", (byte)30, (byte)0);
		
		Classes.File softwareSecurityXLSX = new Classes.File("Software Security.xlsx", (byte)31, 400, 300, 450, CurrentStage.NotOwned, FileType.xlsx, 200, 150, 250);
		Classes.File activityPlanXLSX = new Classes.File("Activity Plan.xlsx", (byte)32, 400, 300, 450, CurrentStage.NotOwned, FileType.xlsx, 200, 150, 250);
		CorruptFile corruptFile3 = new CorruptFile("Corrupt File", (byte)33);
		Classes.File ganttChartXLSX = new Classes.File("Gantt Chart.xlsx", (byte)34, 400, 300, 450, CurrentStage.NotOwned, FileType.xlsx, 200, 150, 250);
		FileExplorer fileExplorer4 = new FileExplorer("File Explorer 4", (byte)35, 50);
		
		Captcha captcha3 = new Captcha("Captcha", (byte)36, games);
		Classes.File securityInformationONE = new Classes.File("Security Information.one", (byte)37, 500, 400, 1000, CurrentStage.NotOwned, FileType.one, 300, 200, 500);
		Location bestFriendJPG = new Location("Best Friend.jpg", (byte)38);
		Classes.File networkAnalysisOne = new Classes.File("Network Analysis.one", (byte)39, 500, 400, 1000, CurrentStage.NotOwned, FileType.one, 300, 200, 500);
		
		//locationArray = new Location[0];
		Location[] temp = {go, softwareProcessMPP, corruptFile1, practicalProjectManagementMPP, util1, fileExplorer1, scrumDOCX, captcha1, userStoriesDOCX, useCasesAndStoriesDOCX, safeMode, 
				softwareVerifcationSVG, util2, requirementsEngineeringSVG, requirementsEngineeringAnalysisSVG, fileExplorer2, umlClassDiagramsPPTX,corruptFile2, softwareImplementationPPTX, designDosAndDontsPPTX, recycleBin, 
				uiPatternsPDF, captcha2, softwareAssurancePDF, designQualityPDF, fileExplorer3, pairProgrammingMP4, sprintRetrospectiveMP4, util3, agileManifestoMP4, downloadVirus,
				softwareSecurityXLSX, activityPlanXLSX, corruptFile3, ganttChartXLSX, fileExplorer4, captcha3, securityInformationONE, bestFriendJPG, networkAnalysisOne};
		locationArray = temp;
		
	}

	/* Displays the leaderboard of the game
	 * @author Dean Logan
	 */
	public void displayResults() {
		int numOfPlayers = playerArray.length;
		int[] playerScores = new int[numOfPlayers];
		
		for(int i=0; i<numOfPlayers; i++) {
			playerScores[i] = playerArray[i].getStorageSpace();
		}
		
		//sorts the playerArray based on the players storageSpace (aka score)
		int swaps;
		do {
			swaps = 0;
			for(int i=0; i<numOfPlayers-1; i++) {
				if(playerScores[i] < playerScores[i+1]) {
					//sorting all of the players scores
					int tempScore = playerScores[i];
					playerScores[i] = playerScores[i+1];
					playerScores[i+1] = tempScore;
					
					//updating player array based on players scores
					Player tempPlayer = playerArray[i];
					playerArray[i] = playerArray[i+1];
					playerArray[i+1] = tempPlayer;
					
					swaps++;
				}
			}
		} while(swaps > 0);
		
		//checks the players position to see the order the players went out (position is changed to a negative number when they went out of the game)
		int positionAt;
		Player[] temp = playerArray;
		for(int i=0; i<numOfPlayers; i++) {
			positionAt = playerArray[i].getPositionAt();
			System.out.println(playerArray[i].getName()+" at "+positionAt);
			if(positionAt < 0) {
				positionAt = -positionAt;
				temp[numOfPlayers-positionAt] = playerArray[i];
			}
		}
		playerArray = temp;
		
		for(int i=numOfPlayers; i>0; i--) {
			System.out.println(playerArray[i-1].getName() + " you came in "+i+" place! Congrats");
		}
		System.out.println("");
	}
	
	/* Displays the rules to the players
	 * @author Dean Logan
	 */
	public void displayRuleSet() throws FileNotFoundException {
		System.out.println("Hello, and welcome to Technopoly! The aim of this game is to become the King/Queen of Hard Disk Drive real estate (sound familiar?).");
		System.out.println("");
		System.out.println("You have all been given access to your own accounts on a computer system. At the start of the game, the hard disk drive is empty,\n it is up to you to set up, download and install files onto the drive, from the internet. \nYou will have access to these files by navigating through the game board via the dice. When you land on a file you would like to organise, \nyou can do so in exchange for your allocated hard disk space. Alternatively, if you land on a file owned by another player, \nyou should be aware that there will be certain overheads associated with running that file (cache data etc.). \nThis will be reflected in your accounts allocated disk space");
		System.out.println("");
		System.out.println("You should also be aware that downloading files from the internet is not always plain sailing, but never fear, the computer system knows this. \nIf you should land on the Downloading a Virus location, you will be rebooted into Safe Mode. \nUnfortunately you may have to miss a turn if this occurs, or you can offer up disk space for your freedom. \nAdditionally, if the computers CAPTCHA system suspects you may be a bot, you will be sent into Safe Mode. ");
		System.out.println("");
		System.out.println("Once you have downloaded files there is always the risk that a file could become corrupted. In this case, the file will be sent to the Recycling Bin \napplication to protect the computer system. However, you may have the chance to save these files upon \nlanding on this location, if you can remember them");
		System.out.println("");
		System.out.println("Players also have the ability to vote to end the game at any time, and one shall reign victorious!");
		System.out.println("");
		
	}
	
	/* Displays the board and the players positions to the players
	 * @author Dean Logan
	 */
	public void displayBoardLayout() {
		String boardLayout = "Board Layot"+System.lineSeparator()+"-----------";
		String header = " Position | Location";
		
		//finds the length of the longest location name
		int longestLocationNameLen = 0;
		int locationNameLen;
		for(int i=0; i<locationArray.length; i++) {
			locationNameLen = locationArray[i].getName().length();
			if(locationNameLen > longestLocationNameLen) {
				longestLocationNameLen = locationNameLen;
			}
		}
		
		header = addSpacePadding(header, longestLocationNameLen-8);
		header += " | Player";
		boardLayout += System.lineSeparator()+header+System.lineSeparator();
		
		for(int i=0; i<header.length()+10; i++) {
			boardLayout += "-";
		}
		
		String newLine;
		for(int i=0; i<locationArray.length; i++) {
			//adds the position to the table
			newLine = " ";
			byte position = locationArray[i].getPosition();
			newLine += (locationArray[i].getPosition());
			newLine = addSpacePadding(newLine, 9-Integer.toString(position).length());
			newLine += "| ";
			
			//adds the location name to the table
			String locationName = locationArray[i].getName();
			newLine +=locationName;
			newLine = addSpacePadding(newLine, longestLocationNameLen-locationName.length());
			newLine += " | ";
			
			//adds the players at this position to the table. Creating a new line with the necessary padding if players are at the same position
			int playersAtPos = 0;
			for(int j=0; j<playerArray.length; j++) {
				if(playerArray[j].getPositionAt() == position) {
					String playerLine = "";
					playersAtPos++;
					if(playersAtPos > 1) {
						playerLine = System.lineSeparator()+addSpacePadding(playerLine, 9)+" |"+addSpacePadding(playerLine, longestLocationNameLen+2)+"| ";
					}
					newLine += playerLine;
					newLine += playerArray[j].getName();
				}
			}
			
			boardLayout += System.lineSeparator()+newLine;
		}
		
		System.out.println(boardLayout);
	}
	
	/* adds any necessary space padding to the end of a string
	 * @param string - string the padding will be added to
	 * @param spacePadding - the number of spaces to be added
	 * @return string - updated string
	 * @author Dean Logan
	 */
	public String addSpacePadding(String string, int spacePadding) {
		for(int i=0; i<spacePadding; i++) {
			string += " ";
		}
		return string;
	}
	
	/* Ends the game
	 * @author Dean Logan
	 */
 	public boolean finishGame(Player[] playerArray) throws FileNotFoundException { // honestly could just remove this method
		displayResults();
		titleScreen();
		return true;
	}
	
 	/* This is responsable for displaying the menu the player sees any time it is their turn. It will also take their input and run the corresponding method
 	 * @author Dean Logan
 	 */
	public void displayOptionsForPlayer() throws FileNotFoundException {
		int numOfPlayersWithBits = 0;
		int numOfPlayers = playerArray.length;
		byte currentPlayerId = currentPlayer.getId();
		
		//This loop will go through each of the players with the purpose of seeing how many players have 0 bits
		for(int i=0; i<numOfPlayers; i++) {
			if(playerArray[i].getStorageSpace() > 0) {
				numOfPlayersWithBits ++;
			}
		}
		if(numOfPlayersWithBits <= 1) {
			finishGame(playerArray); //ends the game if only 1 player has bits left
		}
		
		//checks to see if the currentPlayer is out of bits to ensure they do not have another go
		if(currentPlayer.getStorageSpace() <=0) {
			System.out.println("");
			System.out.println(currentPlayer.getName()+" you are out of bits and therefore out of the game");
			System.out.println("");
			
			//checks to see if the player is already out of the game by seeing if their position is below 0 (as a negative position indicates the order the players have been put out of the game)
			if(currentPlayer.getPositionAt() >= 0) {
				currentPlayer.setPositionAt(-numOfPlayersWithBits); //if this is the first go since they have 0 bits their position will be updated by their placing in the game (see Player class for more notes)
			}
			
			//sets all of the player who has just went out files to notOwned so other players can buy them now
			Classes.File[] filesOwned = currentPlayer.getFilesOwned();
			Classes.File[] emptyFileArr = {};
			if(filesOwned.length == emptyFileArr.length) {
				for(int i=0; i<filesOwned.length; i++) {
					filesOwned[i].setCurrentStage(CurrentStage.NotOwned);
				}
			}
			currentPlayer.setFilesOwned(emptyFileArr);
			
			//updates currentPlayer to the next player in the playerArray
			if(currentPlayerId == numOfPlayers-1) { //checks if the currentPlayer is the last in the playerArray then loops back to start of the array if this is the case
				currentPlayer = playerArray[0];
			}
			else {
				currentPlayer = playerArray[currentPlayerId+1];
				currentPlayerId = currentPlayer.getId();
			}
			displayOptionsForPlayer(); //this means there will be another check to see if the new currentPlayer has any bits
		}
		
		
		//check to see if the currentPlayer is in safe mode - should the player have options displayed to them if they are in safe mode?
		if(locationArray[currentPlayer.getPositionAt()] instanceof SafeMode) {
			SafeMode safeMode = (SafeMode)locationArray[currentPlayer.getPositionAt()];
			if(safeMode.searchPlayerInSafeMode(currentPlayer)) {
				safeMode.displayOptionsForFreedom(currentPlayer); //might need to change this later on 
				
				//goes to next player
				if(currentPlayerId == numOfPlayers-1) {
					currentPlayer = playerArray[0];
				}
				else {
					currentPlayer = playerArray[currentPlayerId+1];
				}
				displayOptionsForPlayer();
			}
		}
		
		//giving player options
		while(true){
			System.out.println("");
			System.out.println(currentPlayer.getName()+" you currently have "+currentPlayer.getStorageSpace()+" bits");
			System.out.println("");
			System.out.println(currentPlayer.getName()+" please choose from the list below:");
			System.out.println("1. Roll Dice");
			System.out.println("2. Organise Files");
			System.out.println("3. Display Board Layout");
			System.out.println("4. Display Rules");
			System.out.println("5. Save Game");
			System.out.println("6. Vote To Finish Game");
			
			System.out.println("");
			System.out.print("Please enter your choice: ");
			Scanner input = new Scanner(System.in);
			String option = input.nextLine();
			option = option.replaceAll(" ", "");
			
			if(option.compareToIgnoreCase("1") == 0 || option.compareToIgnoreCase("RollDice") == 0) {
				System.out.println("");
				movePlayer();
			}
			else if(option.compareToIgnoreCase("2" ) == 0 || option.compareToIgnoreCase("OrganiseFiles") == 0) {
				organiseFiles();
			}
			else if(option.compareToIgnoreCase("3") == 0 || option.compareToIgnoreCase("DisplayBoardLayout") == 0) {
				System.out.println("");
				displayBoardLayout();
			}
			else if(option.compareToIgnoreCase("4") == 0 || option.compareToIgnoreCase("DisplayRules") == 0) {
				System.out.println("");
				try {
					displayRuleSet();
				} 
				catch (FileNotFoundException e) {
					System.out.println("WARNING - Rules text file could not be found");
				}
			}
			else if(option.compareToIgnoreCase("5") == 0 || option.compareToIgnoreCase("SaveGame") == 0) {
				System.out.println("");
				savingGame();
			}
			else if(option.compareToIgnoreCase("6") == 0 || option.compareToIgnoreCase("VoteToFinishGame") == 0) {
				System.out.println("");
				voteToFinishGame();
			}
			else {
				System.out.println("Please select a valid option from the list by either entering the number or the name of the option you wish to select");
			}
		}
		
	}
	
	/* Responsible for taking the vote which will end the game
	 * @author Dean Logan
	 */
	public void voteToFinishGame() throws FileNotFoundException {
		int yesVotes = 0;
		int noVotes = 0;
		System.out.println("The vote to end the game has begun");
		System.out.println("");
		//gets each of the users vote
		for(int i=0; i<playerArray.length; i++) {
			while(true) {
				System.out.print(playerArray[i].getName()+" Do you wish to end the game? (y/n): ");
				Scanner input = new Scanner(System.in);
				String option = input.nextLine();
				option = option.replaceAll(" ", "");;
				
				if (option.compareToIgnoreCase("y") == 0 || option.compareToIgnoreCase("Yes") == 0) {
					yesVotes++;
					break;
				}
				else if(option.compareToIgnoreCase("n") == 0 || option.compareToIgnoreCase("No") == 0) {
					noVotes++;
					break;
				}
				else {
					System.out.println("Please enter either yes or no");
				}
			}
		}
		//checks the number of yes and no votes
		if(yesVotes > noVotes) {
			System.out.println("The majority of players have voted to end the game.");
			System.out.println("");
			finishGame(playerArray);
		}
		else if (yesVotes == noVotes) {
			System.out.println("There was no majority. Since a Conclusion could not be reached, the game will continue.");
		}
		else {
			System.out.println("The majority of players have voted to continue the game.");
		}
	}
	
	/* Responsible for the rolling of the dice and the moving of the player around the board. It will also call the necessary method where ever the user lands
	 * @author Dean Logan
	 */
	public void movePlayer() throws FileNotFoundException {
		int numOfPlayers = playerArray.length;
		byte currentPlayerId = currentPlayer.getId();
		int currentPlayerPosition = currentPlayer.getPositionAt();
		
		//rolling dice
		int rolledValue1 = diceOne.rollDice();
		int	rolledValue2 = diceTwo.rollDice();
		int rolledValue = rolledValue1 + rolledValue2;
		
		int newPosition = currentPlayerPosition + rolledValue;
		
		//incase the newPosition has been set below 0 while the player has bits, this will make the newPosition a valid number 
		if(newPosition < 0 && currentPlayer.getStorageSpace() >= 0) {
			newPosition = rolledValue;
		}
		
		//passing go
		if(newPosition >= 40) {
			newPosition = newPosition % 40; //the modulo operator is used here to insure no matter what the newPosition is it will always be below 40
			if(locationArray[0] instanceof Go) { 
				((Go)locationArray[0]).givePlayerCollectAmount(currentPlayer);
			}
		}
		
		//tells the user what they have rolled
		System.out.println(currentPlayer.getName()+" you have rolled a "+rolledValue1+" and a "+rolledValue2+" meaning you will move "+rolledValue+" places");
		System.out.println("You have moved from position "+currentPlayer.getPositionAt()+" to "+newPosition);
		
		currentPlayer.setPositionAt(newPosition);
		Location locationAt = locationArray[newPosition];
		
		System.out.println("You have landed on "+locationAt.getName());
		if(locationAt instanceof Classes.File) {
			if(((Classes.File) locationAt).checkWhoOwnsFile(playerArray) == null){
				while(true) {
					System.out.print("Do you wish to download this file for "+((Classes.File)locationAt).getDownloadSpaceRequired()+" (y/n): ");
					Scanner input = new Scanner(System.in);
					String opt = input.nextLine();
					
					if(opt.compareToIgnoreCase("y") == 0 || opt.compareToIgnoreCase("Yes") == 0) {
						((Classes.File)locationAt).downloadingFile(currentPlayer);
						break;
					}
					else if(opt.compareToIgnoreCase("n") == 0 || opt.compareToIgnoreCase("No") == 0) {
						System.out.println("You have decided not to download the file "+locationAt.getName());
						break;
					}
					else {
						System.out.println("Please select either yes or no");
					}
				}
			}
			else if(((Classes.File) locationAt).checkWhoOwnsFile(playerArray).equals(currentPlayer)) {
				System.out.println("You own this file");
			}
			else {
				Player owner = ((Classes.File) locationAt).checkWhoOwnsFile(playerArray);
				System.out.println("The user "+owner.getName()+" owns this file");
				usedQuestions = ((Classes.File) locationAt).playBruteForce(questionsAndAnswers, usedQuestions, currentPlayer, owner);
			}
		}

		else if(locationAt instanceof Captcha) {
			System.out.println("You must complete this captcha");
			locationArray[10] = ((Captcha)locationAt).processResult(currentPlayer, (SafeMode) locationArray[10]); //this updates the safe mode location with the new information
		}
		else if(locationAt instanceof DownloadVirus) {
			System.out.println("You are now downloading a virus");
			locationArray[10] = ((DownloadVirus)locationAt).downloadingVirus(currentPlayer, (SafeMode) locationArray[10]); //this updates the safe mode location with the new information
		}
		else if(locationAt instanceof CorruptFile) {
			System.out.println("You now have a corrupted file");
			locationArray[20] = ((CorruptFile)locationAt).loseFile(currentPlayer, (RecyclingBin)locationArray[20]);
		}
		else if(locationAt instanceof Utility) {
			System.out.println("You have opened up utility and now have gained a util pass!");
			((Utility)locationAt).givePlayerUtilCard(currentPlayer);
		}
		else if(locationAt instanceof RecyclingBin) {
			System.out.println("You have opened up the recycling bin");
			((RecyclingBin)locationAt).playMemoryGame(currentPlayer);
		}
		else if(locationAt instanceof FileExplorer) {
			System.out.println("You have opened up the file explorer");
			((FileExplorer)locationAt).selectOption(currentPlayer);
		}
		
		//goes to next player
		if(currentPlayerId == numOfPlayers-1) {
			currentPlayer = playerArray[0];
		}
		else {
			currentPlayer = playerArray[currentPlayerId+1];
		}
		
		displayOptionsForPlayer();
	}
	
	/* This will role the dice for each players then set their order in the playerArray based on the numbers rolled
	 * @author Dean Logan
	 */
	public void determinePlayerOrder() throws FileNotFoundException {
		int numOfPlayers = playerArray.length;
		int[] playersRolls = new int[numOfPlayers];
		
		System.out.println("");
		System.out.println("Now lets roll to see what order everyone will be playing in!");
		System.out.println("");
		
		for(int i=0; i<numOfPlayers; i++) {
			int rolledValue1 = diceOne.rollDice(); 
			int	rolledValue2 = diceTwo.rollDice(); 
			playersRolls[i] = rolledValue1+rolledValue2;
			System.out.println(playerArray[i].getName()+" you have rolled "+playersRolls[i]);
		}
		
		//below will sort the playerArray array based on what the player rolled which is stored in playerRolls
		//this is done by sorting the playersRolls array then doing the same swaps in the playerArray
		//it works as the index of the player and their roll are the same in the 2 arrays
		int swaps;
		do {
			swaps = 0;
			for(int i=0; i<numOfPlayers-1; i++) {
				if(playersRolls[i] < playersRolls[i+1]) {
					//sorting all of the players rolls
					int tempRoll = playersRolls[i];
					playersRolls[i] = playersRolls[i+1];
					playersRolls[i+1] = tempRoll;
					
					//updating player array based on rolls
					Player tempPlayer = playerArray[i];
					playerArray[i] = playerArray[i+1];
					playerArray[i+1] = tempPlayer;
					
					//updating id of the players
					playerArray[i].setId((byte)i);
					playerArray[i+1].setId((byte)(i+1));
					
					swaps++;
				}
			}
		} while(swaps > 0);
		
		currentPlayer = playerArray[0];
		
		System.out.println("");
		for(int i=0; i<numOfPlayers; i++) {
			System.out.println(playerArray[i].getName()+" you will go "+(i+1));
		}
		
		displayOptionsForPlayer();
	}
	
	/* Displays the title screen for the user and will take the users option and run the corresponding method
	 * @author Dean Logan
	 */
	public void titleScreen() throws FileNotFoundException {
		while(true){
			System.out.println("Technopoly!");
			System.out.println("1. Start Game");
			System.out.println("2. Continue Game");
			System.out.println("3. Exit");
			
			System.out.println("");
			System.out.print("Please enter your choice: ");
			Scanner input = new Scanner(System.in);
			String option = input.nextLine();
			option = option.replace(" ", "");
			
			if(option.compareToIgnoreCase("1") == 0 || option.compareToIgnoreCase("StartGame") == 0) {
				System.out.println("");
				System.out.println("The game is starting :)");
				initialisePlayers();
				initialiseDice();
				initialiseLocations();
				determinePlayerOrder();
			}
			else if(option.compareToIgnoreCase("2") == 0 || option.compareToIgnoreCase("ContinueGame") == 0) {
				savedGames();
			}
			else if(option.compareToIgnoreCase("3") == 0 || option.compareToIgnoreCase("Exit") == 0) {
				System.out.println("");
				System.out.println("Game has ended Goodbye!");
				System.exit(0);
				break;
			}
			else {
				System.out.println("");
				System.out.println("Please enter either the number of the option or the name of the option listed.");
				System.out.println("");
			}
		}

	}
		
	/* This is the menu for when a player wants to upgrade a file
	 * @author Dean Logan
	 */
	public void organiseFiles() {
		Classes.File[] filesOwned = currentPlayer.getFilesOwned();
		int filesOwnedLen = filesOwned.length;
		Classes.File fileBeingEdited = null;
		
		//checks if a player owns any files
		if(filesOwnedLen > 0) {
			while(true){
				System.out.println("");
				System.out.println(currentPlayer.getName()+" you currently have "+currentPlayer.getStorageSpace()+" bits");
				System.out.println("");
				System.out.println("Please choose from the list below:");
				//displays only the files the player owns
				for(int i=0; i<filesOwnedLen; i++) {
					System.out.println((i+1)+". "+filesOwned[i].getName()+" - "+filesOwned[i].getCurrentStage());
				}
				System.out.println((filesOwnedLen+1)+". Back");

				System.out.println("");
				System.out.print("Please select an option: ");
				Scanner input = new Scanner(System.in);
				String option = input.nextLine();
				option = option.replace(" ","");
				
				if(option.compareToIgnoreCase("Back") == 0 || option.compareToIgnoreCase(String.valueOf(filesOwnedLen+1)) == 0) {
					break;
				}
				
				//allows the user to enter the number the file is at in the menu or the name of the file
				try {
					int optionNum = Integer.valueOf(option);
					if(optionNum <= filesOwnedLen && optionNum > 0) { 
						fileBeingEdited = filesOwned[optionNum-1];
					}
					else {
						System.out.println("Please select one of the files above");
					}
				}
				catch (NumberFormatException ex){
					for(int i=0; i<filesOwnedLen; i++) {
						if(filesOwned[i].getName().replace(" ", "").compareToIgnoreCase(option) ==0) {
							fileBeingEdited = filesOwned[i];
							break;
						}
					}
					if(fileBeingEdited == null) {
						System.out.println("Please select one of the files above");
					}
				}
				if(fileBeingEdited != null) {
					//checks the stage of the file to run the correct upgrade method within the file class
					CurrentStage currentStage = fileBeingEdited.getCurrentStage();
					int fileSpaceRequired = 0;

					if(currentStage != CurrentStage.Setup3) {
						fileSpaceRequired = fileBeingEdited.getSetupSpaceRequired();
					}
					else if(currentStage != CurrentStage.Installed){
						fileSpaceRequired = fileBeingEdited.getInstallationSpaceRequired();
					}

					System.out.print("Do you want to contine seting up this file for "+fileSpaceRequired+" (y/n): ");
					String opt = input.nextLine();
					opt = opt.replaceAll(" ", "");

					if(opt.compareToIgnoreCase("y") == 0 || opt.compareToIgnoreCase("Yes") == 0) {
						if(fileSpaceRequired != 0) {
							//might need to change these getters and setters to the methods already in the File class
							if(currentStage != CurrentStage.NotOwned && currentStage != CurrentStage.Setup3) {
								fileBeingEdited.setupProcess(currentPlayer);
							}
							else if(currentStage == CurrentStage.Setup3) {
								fileBeingEdited.installingFile(currentPlayer);
							}
						}
						else {
							System.out.println("This file has already been installed");
						}
					}
				}
			}
		}
		else {
			System.out.println("You have no files to organise");
		}
	}
	
	//standard getters and setters
	public Player[] getPlayerArray() {
		return playerArray;
	}

	public void setPlayerArray(Player[] playerArray) {
		this.playerArray = playerArray;
	}

	public Dice getDiceOne() {
		return diceOne;
	}

	public void setDiceOne(Dice diceOne) {
		this.diceOne = diceOne;
	}

	public Dice getDiceTwo() {
		return diceTwo;
	}

	public void setDiceTwo(Dice diceTwo) {
		this.diceTwo = diceTwo;
	}

	public Location[] getLocationArray() {
		return locationArray;
	}

	public void setLocationArray(Location[] locationArray) {
		this.locationArray = locationArray;
	}

	public Player getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}
}
