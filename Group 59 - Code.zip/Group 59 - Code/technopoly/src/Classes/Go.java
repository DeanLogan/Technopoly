package Classes;

public class Go extends Location{
	private int collectAmount;
	
	public Go(String name, byte position, int collectAmount) {
		super(name, position);
		this.collectAmount = collectAmount;
	}
	
	/* Gives the player the collect amount when they pass go
	 * @param user - Player to give the collect amount to 
	 * @author JB Higgins 
	 */
	public int givePlayerCollectAmount(Player user) {
		int collectAmount = getCollectAmount();
		int currentStorageSpace = user.getStorageSpace();
		
		int storageSpace = collectAmount + currentStorageSpace;
		user.setStorageSpace(storageSpace);
		System.out.println("You have recieved 200 bits for passing Go!");
		return 1;
	}
	
	//standard getters and setters
	public int getCollectAmount() {
		return collectAmount;
	}

	public void setCollectAmount(int collectAmount) {
		this.collectAmount = collectAmount;
	}
}