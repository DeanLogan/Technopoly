package Classes;

public class Location {
	private String name;
	private byte position;
	
	public Location(String name, byte position) {
		this.name = name;
		this.position = position;
	}
	
	//standard getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte getPosition() {
		return position;
	}

	public void setPosition(byte position) {
		this.position = position;
	}
}
