package Classes;

public class Player {
	private String name;
	private byte id; 
	private int storageSpace;
	private File[] filesOwned;
	private byte utilPass;
	private int positionAt; //whenever a user is out of the game their storage space will indicate when they got eliminated from the game. (e.g -1 if the player went out first then -2 if the player went out second etc) 
	
	
	public Player(String name, byte id, int storageSpace, File[] filesOwned, byte utilPass, int positionAt) {
		this.name = name;
		this.id = id;
		this.storageSpace = storageSpace;
		this.filesOwned = filesOwned;
		this.utilPass = utilPass;
		this.positionAt = positionAt;
	}

	//standard getters and setters
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public byte getId() {
		return id;
	}


	public void setId(byte id) {
		this.id = id;
	}


	public int getStorageSpace() {
		return storageSpace;
	}


	public void setStorageSpace(int storageSpace) {
		this.storageSpace = storageSpace;
	}

	public File[] getFilesOwned() {
		return filesOwned;
	}
	
	public void setFilesOwned(File[] filesOwned) {
		this.filesOwned = filesOwned;
	}

	public byte getUtilPass() {
		return utilPass;
	}


	public void setUtilPass(byte utilPass) {
		this.utilPass = utilPass;
	}

	public int getPositionAt() {
		return positionAt;
	}


	public void setPositionAt(int positionAt) {
		this.positionAt = positionAt;
	}
}
