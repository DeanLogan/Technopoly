package Classes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class RecyclingBin extends Location{
	private File[] corruptFileArray;
	
	public RecyclingBin(String name, byte position, File[] corruptFileArray) {
		super(name, position);
		this.corruptFileArray = corruptFileArray;
	}
	
	/* Starts the memory game
	 * @param user - Player who will be taking part in the memory game
	 * @author Scott McDonald
	 */
	public void playMemoryGame(Player user) {
		Classes.File fileCorrect = null;
		int corruptFilesLen = corruptFileArray.length;
		System.out.println("Welcome "+user.getName()+"!"+"\n"+"On this location you have the oportunity to claim all corrupted files for zero cost."+"\n"+"All you have to do is recall the name of the file in full, i.e. 'BestFriend.jpeg'."+"\n"+"Failure to meet these simple requirements will result in the acquisition of no new properties and you majoryly sucking."+"\n"+"There are currently "+corruptFilesLen+" files corrupted."+"\n"+"You can type 'Back' at any time to exit the Memory Game.");			
		if (corruptFileArray.length >= 1) {
			while(true) {		
				System.out.println("");
				System.out.print("Enter your guess: ");
				Scanner input = new Scanner(System.in);
				String option = input.nextLine();
				option = option.replace(" ","");
				
				if(option.compareToIgnoreCase("Back") == 0) {
					System.out.println("Exiting Game."+"\n");
					break;
				}
				
				try {
					boolean found = false;
					for(int i=0; i<corruptFilesLen; i++) {
						if(corruptFileArray[i].getName().replace(" ","").compareToIgnoreCase(option) == 0) {
							fileCorrect = corruptFileArray[i];
							found = true;
						}
					}
					if(!found) {
						System.out.println("Wrong. Enter both the name and type of the file. It is not case sensitive or require spaces.");
					}
				}
				catch (NumberFormatException ex){
					for(int i=0; i<corruptFilesLen; i++) {
						if(corruptFileArray[i].getName().replace(" ","").compareToIgnoreCase(option) ==0) {
							fileCorrect = corruptFileArray[i];
							break;
						}
					}
					if(fileCorrect == null) {
						System.out.println("Wrong. Enter both the name and type of the file. It is not case sensitive or require spaces.");
					}
				}
				if(fileCorrect != null) {
					int fileSpaceRequired = fileCorrect.getSetupSpaceRequired();
					System.out.println("Congratulations! This file is worth "+fileSpaceRequired+"  bits."+"\n"+"Are you happy to accept this file? (y/n): ");
					String opt = input.nextLine();
					opt = opt.replaceAll(" ","");
					
					if(opt.compareToIgnoreCase("y") == 0 || opt.compareToIgnoreCase("Yes") == 0) {
						giveFilesToPlayer(user, fileCorrect);
						break;
					}
					else {
						System.out.println("Exiting menu"+"\n");
						break;
					}
				}
			}
		
		}
		else {
			System.out.println("There are no corrupted files."+"\n"+"Maybe next time?"+"\n");
		}
	}
	
	/* Gives the file to the player who completed the memory game
	 * @param user - Player who will get the file
	 * @param location - File to give to the user
	 * @author Scott McDonald
	 */
	public void giveFilesToPlayer(Player user, File location) {
		location.setCurrentStage(CurrentStage.Downloaded);
		File[] filesOwned = user.getFilesOwned();
		int numOfFilesOwned = filesOwned.length;
		File[] tempArray = new File[numOfFilesOwned+1];
		for(int i=0; i<numOfFilesOwned; i++ ) {
			tempArray[i] = filesOwned[i];
		}
		
		//removes file from recycling bin
		File[] tempArray2 = new File[corruptFileArray.length-1];
		int j=0;
		for(int i=0; i<corruptFileArray.length; i++) {
			if(!corruptFileArray[i].equals(location)) {
				tempArray2[j] = corruptFileArray[i];
				j++;
			}
		}
		corruptFileArray = tempArray2;
		
		tempArray[numOfFilesOwned] = location;
		user.setFilesOwned(tempArray);
		System.out.println("You have successfully downloaded this file."+"\n");
	}
	
	//standard getters and setters
	public File[] getCorruptFileArray() {
		return corruptFileArray;
	}
	
	public void setCorruptFileArray(File[] corruptFileArray) {
		this.corruptFileArray = corruptFileArray;
	}
}
