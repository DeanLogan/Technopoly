package Classes;

import java.util.Scanner;

public class SafeMode extends Location{
	private Player[] playersInSafeMode;
	private byte[] timeSpentInSafeMode;
	
	public SafeMode(String name, byte position, Player[] playersInSafeMode, byte[] timeSpentInSafeMode) {
		super(name, position);
		this.playersInSafeMode = playersInSafeMode;
		this.timeSpentInSafeMode = timeSpentInSafeMode;
	}
	
	/* Sends the user to safe mode for the specified amount of time
	 * @param user - Player who will be going to SafeMode
	 * @param time - The amount of turns the user will be in safeMode for
	 * @author Dean Logan
	 */
	public void goToSafeMode(Player user, int time){
		user.setPositionAt(10);

		int numInSafeMode = playersInSafeMode.length;
		for(int i=0; i<numInSafeMode; i++){
			if(playersInSafeMode[i] == null) {
				playersInSafeMode[i] = user;
				timeSpentInSafeMode[i] = (byte)time; 
				break;
			}
		}
	}

	/* Charges the user 1500 bits to get out of SafeMode earlier than their time 
	 * @param user - Player who will be getting out of safeMode
	 * @author Dean Logan
	 */
	public boolean buyForFreedom(Player user) { 
		int userBits = user.getStorageSpace();
		
		if(userBits > 1500) {
			user.setStorageSpace(userBits-1500);
			return true;
		}
		else {
			System.out.println("You do not have enough bits to get out of safe mode");
			return false;
		}
	}
	
	/* Allows the user to see if they can roll a double to get out of safeMode sooner
	 * @param user - Player who will be getting out of safeMode
	 * @author Dean Logan
	 */
	public boolean rollForFreedom(Player user) {
		Dice diceOne = new Dice(0);
		Dice diceTwo = new Dice(0);
		
		int rolledValue1 = diceOne.rollDice();
		int rolledValue2 = diceTwo.rollDice();
		
		System.out.println("You have rolled a "+rolledValue1+ " and a "+rolledValue2);
		
		if(rolledValue1 == rolledValue2) {
			return true;
		}
		System.out.println("As you have not rolled a double you will remain in safe mode");
		return false;
	}
	
	/* Displays the options that the user has when they are in safeMode
	 * @param user - Player in safeMode
	 * @author Dean Logan
	 */
	public void displayOptionsForFreedom(Player user) { 
		int time = 0;
		for(int i=0; i<playersInSafeMode.length; i++) {
			if(!(playersInSafeMode[i] == null) && playersInSafeMode[i].equals(user)) {
				time = timeSpentInSafeMode[i];
			}
		}
		if(time == 0) {
			return; 
		}
		
		while(true) {
			System.out.println("");
			System.out.println(user.getName()+", you are currently stuck in Safe Mode for "+time+".");
			System.out.println("To get out of Safe Mode you can either:");
			System.out.println("1. Roll a Double");
			System.out.println("2. Use 1500 bits to get out of Safe Mode");
			System.out.println("");
			System.out.print("Please enter your choice: ");
			Scanner input = new Scanner(System.in);
			String option = input.nextLine();
			option = option.replaceAll(" ", "");
			
			if(option.compareToIgnoreCase("1") == 0 || option.compareToIgnoreCase("RollDice") == 0) {
				if(rollForFreedom(user)) {
					System.out.println("You have successfully rolled a double to gain your freedom - well done!");
					getFreedom(user);
				}
				break;
			}
			else if(option.compareToIgnoreCase("2") == 0 || option.compareToIgnoreCase("UseStorageSpaceToGetOut") == 0 || option.compareToIgnoreCase("StorageSpace") == 0 || option.compareToIgnoreCase("use1500bitstogetoutofsafemode") == 0) {
				if(buyForFreedom(user)) {
					System.out.println("You have successfully paid your way out of safe mode");
					getFreedom(user);
				}
				break;
			}
			else {
				System.out.println("Please select a valid option from the list by either entering the number or the name of the option you wish to select");
			}	
		}
	}
	
	/* This will remove the user from safeMode
	 * @param user - Player in safeMode
	 * @author Dean Logan
	 */
	public void getFreedom(Player user) {
		for(int i=0; i<playersInSafeMode.length; i++) {
			if(playersInSafeMode[i] != null || user.equals(playersInSafeMode[i])) {
				playersInSafeMode[i] = null;
				timeSpentInSafeMode[i] = 0;
			}
		}
	}
	
	/* Searches the playersInSafeMode array to see if the user is in safe mode
	 * @param user - Player to be searched for
	 * @return true if the user is found false if not
	 * @author Dean Logan
	 */
	public boolean searchPlayerInSafeMode(Player user) {
		for(int i=0; i<playersInSafeMode.length; i++) {
			if(playersInSafeMode[i] != null) {
				if(playersInSafeMode[i].equals(user)) {
					return true;
				}
			}
		}
		return false;
	}
	
	//standard getters and setters
	public Player[] getPlayersInSafeMode() {
		return playersInSafeMode;
	}

	public void setPlayersInSafeMode(Player[] playersInSafeMode) {
		this.playersInSafeMode = playersInSafeMode;
	}

	public byte[] getTimeSpentInSafeMode() {
		return timeSpentInSafeMode;
	}

	public void setTimeSpentInSafeMode(byte[] timeSpentInSafeMode) {
		this.timeSpentInSafeMode = timeSpentInSafeMode;
	}
}
