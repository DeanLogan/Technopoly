package Classes;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;


//this class was just used to test code throughout development
public class Tests {
	
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("The following are tests");
		System.out.println("");
		System.out.println("");
		testMemoryGame();
	}

	//test methods
	
	public static void testStartGame() {
		Game game = new Game();
		game.initialisePlayers();
	}
	
	public static void testGameEnds() {
		Game game = new Game();
		
		playersMidGame(game);
		testRollDice();
		
	}
	
	public static void testUsedQuestions() {
		Game game = new Game();

		playersMidGame(game);

		Location[] locationArr = game.getLocationArray();

		String[][] questionsAndAnswers = game.retrievingQuestionsAndAnswers();
		System.out.println("Current Questions: ");
		for(int i=0;i<questionsAndAnswers.length;i++) {
			System.out.print(Arrays.toString(questionsAndAnswers[i]));
		}
		System.out.println("");
		
		String[] usedQuestions = {};
		System.out.println("Current Used Questions: ");
		for(int i=0;i<usedQuestions.length;i++) {
			System.out.print(usedQuestions[i]);
		}
		System.out.println("");

		Location locationAt = locationArr[(game.getPlayerArray()[0]).getPositionAt()];

		Player owner = game.getPlayerArray()[2];

		game.getPlayerArray()[0].setPositionAt(26);

		usedQuestions = ((Classes.File) locationAt).playBruteForce(questionsAndAnswers, usedQuestions, game.getPlayerArray()[0], owner);
		
		System.out.println("Current Used Questions: ");
		for(int i=0;i<usedQuestions.length;i++) {
			System.out.print(usedQuestions[i]);
		}

	}
	
	public static void testFilesReturnedOnLoss() {
		Game game = new Game();

		playersMidGame(game);

		Location[] locationArr = game.getLocationArray();
		
		Player player = game.getPlayerArray()[3];
		
		System.out.print("Files player owns: ");
		for(int i=0; i<player.getFilesOwned().length; i++) {
			System.out.print(player.getFilesOwned()[i].getName()+", ");
			System.out.print(player.getFilesOwned()[i].getPosition()+", ");
		}
		
		game.setCurrentPlayer(player);
		player.setStorageSpace(0);
		
		System.out.println("Setting player storage space to 0");
		
		try {
			game.displayOptionsForPlayer();
		}
		catch (FileNotFoundException e) {
			System.out.println("Failed");
		}
	}

	public static void testLandOnFile() {
		Game game = new Game();
		playersMidGame(game);
		
		Location[] locationArray = game.getLocationArray();
		Player[] playerArray = game.getPlayerArray();
		
		((Classes.File)locationArray[9]).downloadingFile(playerArray[0]);
	}
	
	public static void testLandOnCorruptFile() {
		Game game = new Game();
		playersMidGame(game);

		CorruptFile corruptFile = (CorruptFile) game.getLocationArray()[2];
		RecyclingBin recyclingBin = (RecyclingBin) game.getLocationArray()[20];
		Player player = game.getPlayerArray()[2];

		System.out.print("Files player owns: ");
		for(int i=0; i<player.getFilesOwned().length; i++) {
			System.out.print(player.getFilesOwned()[i].getName()+", ");
		}
		System.out.println("");
		System.out.println("");

		System.out.print("Files in Recycling Bin: ");
		File[] binFiles = recyclingBin.getCorruptFileArray();
		if(binFiles.length != 0) {
			for(int i=0; i<binFiles.length; i++) {
				System.out.print(binFiles[i].getName()+", ");
			}	
		}
		else {
			System.out.print("No files in bin");
		}
		System.out.println("");
		System.out.println("");

		corruptFile.loseFile(player, recyclingBin);
		System.out.println("");

		File[] test = {};
		System.out.println("length of player owned files: "+test.length);
		System.out.print("Files player owns: ");
		for(int i=0; i<player.getFilesOwned().length; i++) {
			System.out.print(player.getFilesOwned()[i].getName()+", ");
		}
		System.out.println("");
		System.out.println("");

		System.out.print("Files in Recycling Bin: ");
		binFiles = recyclingBin.getCorruptFileArray();
		if(binFiles != null) {
			for(int i=0; i<recyclingBin.getCorruptFileArray().length; i++) {
				System.out.print(binFiles[i].getName()+", ");
			}
		}
		else {
			System.out.print("No files in bin");
		}
		System.out.println("");

	}

	public static void testUserDownloadFile() {
		Game game = new Game();
		players(game);

		try {
			game.displayOptionsForPlayer();
		} 
		catch (FileNotFoundException e) {
			System.out.println("Failed");
		}
	}

	public static void testLandOnFileExplorer() {
		Game game = new Game();
		Utility utility = new Utility("Utility", (byte)4);

		playersMidGame(game);

		Player player = game.getPlayerArray()[0];
		FileExplorer fileExplorer = new FileExplorer("File Explorer 1", (byte)5, 50);
		utility.givePlayerUtilCard(player);


		fileExplorer.selectOption(player);
	}

	public static void testOtherUserOwnsFile() {
		Game game = new Game();
		playersMidGame(game);

		try {
			game.displayOptionsForPlayer();
		} 
		catch (FileNotFoundException e) {
			System.out.println("Failed");
		}
	}

	public static void testLandOnCaptcha() throws FileNotFoundException {
		Game game = new Game();
		players(game);

		String[] games = {"tictactoe", "wordle", "hangMan"};
		Player[] playersInSafeMode = new Player[game.getPlayerArray().length];
		byte[] timeSpentInSafeMode = new byte[game.getPlayerArray().length];

		Captcha captcha1 = new Captcha("Captcha", (byte)7, games);

		Player player = game.getPlayerArray()[0];
		SafeMode safeMode = new SafeMode("Safe Mode", (byte)10, playersInSafeMode, timeSpentInSafeMode);
		captcha1.processResult(player, safeMode);
		//		try {
		//			captcha1.processResult(player, safeMode);
		//		}
		//		catch (FileNotFoundException e) {
		//			System.out.println("Failed");
		//		}
	}

	public static void testDownloadingVirus() {
		Game game = new Game();
		players(game);

		DownloadVirus downloadVirus = (DownloadVirus) game.getLocationArray()[30];
		Player player = game.getPlayerArray()[0];
		Player player2 = game.getPlayerArray()[1];
		SafeMode safeMode = (SafeMode) game.getLocationArray()[10];
		player.setPositionAt(30);

		safeMode = downloadVirus.downloadingVirus(player, safeMode); //sends player to safe mode
		safeMode = downloadVirus.downloadingVirus(player2, safeMode); //then sends player2 to safe mode
		System.out.println("");

		safeMode.displayOptionsForFreedom(player); //this will show player being in safe mode for 1 go
		safeMode.displayOptionsForFreedom(player2); //this will show player2 being in safe mode for 2 goes
	}

	public static void testGoToSafeMode() {
		Game game = new Game();
		players(game);

		DownloadVirus downloadVirus = (DownloadVirus) game.getLocationArray()[30];
		Player player = game.getPlayerArray()[0];
		SafeMode safeMode = (SafeMode) game.getLocationArray()[10];
		player.setPositionAt(30);

		safeMode = downloadVirus.downloadingVirus(player, safeMode);
		System.out.println("");

		System.out.println(player.getName()+" you currently have "+player.getStorageSpace()+" bits");

		safeMode.displayOptionsForFreedom(player);

		System.out.println("");

		System.out.println(player.getName()+" you currently have "+player.getStorageSpace()+" bits");
	}

	public static void testTitleScreen() throws FileNotFoundException {
		Game game = new Game();

		game.titleScreen();
	}

	public static void testDisplayOptionsForPlayer() throws FileNotFoundException {
		Game game = new Game();

		playersMidGame(game);

		game.displayOptionsForPlayer();
	}

	public static void testDisplayBoardLayout() {
		Game game = new Game();

		players(game);

		game.displayBoardLayout();

		System.out.println("");

		playersMidGame(game);

		game.displayBoardLayout();
	}

	public static void testOrganiseFiles() {
		Game game = new Game();

		players(game);

		System.out.println("");

		playersMidGame(game);

		game.organiseFiles();
	}


	//also tests the finishGame() function
	public static void testVoteToFinishGame() throws FileNotFoundException {
		Game game = new Game();

		playersMidGame(game);

		game.voteToFinishGame();
	}

	public static void testMemoryGame() {
		Game game = new Game();

		//game.loadingSavedGame("game1");
		playersMidGame(game);

		Location[] locationArr = game.getLocationArray();

		Classes.File[] filesToCorupt = {(File) locationArr[9], (File) locationArr[39]};

		RecyclingBin recycleBin = (RecyclingBin) locationArr[20];
		recycleBin.setCorruptFileArray(filesToCorupt);

		recycleBin.playMemoryGame(game.getPlayerArray()[0]);
		
		Classes.File[] files = recycleBin.getCorruptFileArray();
		
		for(int i=0; i<files.length; i++) {
			System.out.println(files[i].getName());
		}
		
		game.organiseFiles();
	}

	public static void testBruteForceMiniGame() {
		Game game = new Game();

		playersMidGame(game);

		Location[] locationArr = game.getLocationArray();
		
		System.out.println("Users current bits: " + (game.getPlayerArray()[0]).getStorageSpace());
		System.out.println("Owner current bits: " + (game.getPlayerArray()[1]).getStorageSpace());

		String[][] questionsAndAnswers = game.retrievingQuestionsAndAnswers();

		String[] usedQuestions = {};

		Location locationAt = (File) locationArr[21];

		Player owner = game.getPlayerArray()[1];

		usedQuestions = ((Classes.File) locationAt).playBruteForce(questionsAndAnswers, usedQuestions, game.getPlayerArray()[0], owner);
		
		System.out.println("Users current bits: " + (game.getPlayerArray()[0]).getStorageSpace());
		System.out.println("Owner current bits: " + (game.getPlayerArray()[1]).getStorageSpace());

	}

	public static void testLandOnGO() {
		Game game = new Game();

		playersMidGame(game);

		game.getPlayerArray()[0].setPositionAt(39);
		System.out.println("Users current position: " + game.getPlayerArray()[0].getPositionAt());
		

		try {
			game.displayOptionsForPlayer();
		} catch (FileNotFoundException e) {
			System.out.println("Failed");
		}

	}

	public static void testRollDice() {
		Game game = new Game();

		playersMidGame(game);

		try {
			game.displayOptionsForPlayer();
		} catch (FileNotFoundException e) {
			System.out.println("Failed");
		}
	}

	public static void testLandOnUtility() {
		Game game = new Game();

		playersMidGame(game);

		System.out.println("Number of Util Pass before: "+game.getPlayerArray()[0].getUtilPass());
		
		System.out.println("Users current position: " + game.getPlayerArray()[0].getPositionAt());

		Utility utility = new Utility("Utility", (byte)4);
		
		game.getPlayerArray()[0].setPositionAt(4);

		utility.givePlayerUtilCard(game.getPlayerArray()[0]);

		System.out.println("Number of Util Pass after: "+game.getPlayerArray()[0].getUtilPass());
		
		System.out.println("Users new position: " + game.getPlayerArray()[0].getPositionAt());

		try {
			game.displayOptionsForPlayer();
		} catch (FileNotFoundException e) {
			System.out.println("Failed");
		}

	}

	//some methods that will help you set up stuff in the game

	//this will give the game object 4 players at the start of the game to test with 
	public static void players(Game game) {		
		File[] filesOwned = {}; //might need to change this later to a different number.

		Player player1 = new Player("Dean", (byte)0, 1600, filesOwned, (byte)0, 0);
		Player player2 = new Player("JB", (byte)1, 300, filesOwned, (byte)0, 0);
		Player player3 = new Player("Scott", (byte)2, 1000, filesOwned, (byte)0, 0);
		Player player4 = new Player("Conor", (byte)3, 500, filesOwned, (byte)0, 0);

		Player[] playerArray = {player1, player2, player3, player4};
		game.setCurrentPlayer(player1);

		game.setPlayerArray(playerArray);

		game.initialiseDice();
		game.initialiseLocations();

	}

	//this will give the game object 4 players at the start of the game to test with 
	public static void playersMidGame(Game game) {
		players(game);

		game.getPlayerArray()[0].setPositionAt(24); //Dean
		game.getPlayerArray()[1].setPositionAt(3); //JB
		game.getPlayerArray()[2].setPositionAt(34); //Scott
		game.getPlayerArray()[3].setPositionAt(8); //Conor

		Location[] locationArr = game.getLocationArray();

		//File[] filesOwnedP1 = {(File) locationArr[6],(File) locationArr[19], (File) locationArr[24]};
		File[] filesOwnedP1 = {(File) locationArr[6]};
		File[] filesOwnedP2 = {(File) locationArr[21],(File) locationArr[31]};
		File[] filesOwnedP3 = {(File) locationArr[26],(File) locationArr[8], (File) locationArr[18], (File) locationArr[16], (File) locationArr[23]};
		File[] filesOwnedP4 = {(File) locationArr[1],(File) locationArr[3]};

		game.getPlayerArray()[0].setFilesOwned(filesOwnedP1);
		game.getPlayerArray()[1].setFilesOwned(filesOwnedP2);
		game.getPlayerArray()[2].setFilesOwned(filesOwnedP3);
		game.getPlayerArray()[3].setFilesOwned(filesOwnedP4);

		((File) locationArr[6]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[19]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[24]).setCurrentStage(CurrentStage.Downloaded);

		((File) locationArr[21]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[31]).setCurrentStage(CurrentStage.Downloaded);

		((File) locationArr[26]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[8]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[18]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[16]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[23]).setCurrentStage(CurrentStage.Downloaded);

		((File) locationArr[1]).setCurrentStage(CurrentStage.Downloaded);
		((File) locationArr[3]).setCurrentStage(CurrentStage.Downloaded);
	}

}
