package Classes;

public class Utility extends Location{
	
	public Utility(String name, byte position) {
		super(name, position);
	}
	
	/* Gives a util card to the player
	 * @param user - Player to give util card to 
	 * @author Conor Nugent
	 */
	public void givePlayerUtilCard(Player user) {
		int utilPass = user.getUtilPass() + 1;
		user.setUtilPass((byte) utilPass);
	}
}
